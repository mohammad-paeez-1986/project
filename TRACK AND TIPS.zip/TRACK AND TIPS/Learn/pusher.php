PUSHER :: Broadcasting
-----------------------------------------

WebSocket is a two-way computer communication protocol over a single TCP.

----------------------------------------------------------------------------

1 => install pusher package

composer require pusher/pusher-php-server "~4.0"

2 => uncomment line from config -> app.php

from providers array

App\Providers\BroadcastServiceProvider::class,

3 => change .env

enroll in https://pusher.com/ ( you can sign in with google account )

create new channel app  ...

on getting start tab you can get following data ( in .env from right side )

PUSHER_APP_ID="888121"
PUSHER_APP_KEY="f2135f69bc9768f836cf"
PUSHER_APP_SECRET="2f776f012d041aa72250"

and you can get cluster if you need it. ( you need it dosnt work without )

PUSHER_APP_CLUSTER='ap4'

add them in .env ( fill it )

and  change BROADCAST_DRIVER value from log to pusher

4 => create event class

you can create event class by artisan

php artisan make:event UserRegisterd

add implements ShouldBroadcast toward class name
intialize it with :

<?

    public $msg;

    public function __construct($msg)
    {
        $this->msg = $msg;
}

?>

in broadcastOn method :

change PrivateChannel to Channel and give it a neme you want ...

you can add :

public function broadcastAs()
{
    return "my-name";
}

for use it in javascript

5 => create view

in resources\views
    
create file named: eventPage.blade.php

copy html page fron pusher.com to it

change two things ::

var channel = pusher.subscribe('my-channel');
channel.bind('my-name', function(data) {
  alert(JSON.stringify(data));
});

my-channel in defined in event controller

my-name is event name ( dosnt work with even "\\App\\Events\\UserRegisterd" or "\\App\Events\UserRegisterd")

6 => define two routes

first for load page created by javascript code from pusher here eventPage.blade.php
second a route for fire event like :

Route::get('fireEvent', function () {
    event(new \App\Events\UserRegisterd('messages'));
});
