import React, { useState } from 'react';

const ReportComparativeAdd = () => {
    const [parts, setParts] = useState([]);
    const [name, setName] = useState(['ali']);

    const addPart = () => {
        setParts([...parts, Part]);
    };

    const changeName = (num) => {
        setName((name) => {
            let newName = [...name];
            newName[num] =
                newName[num] === 'ali' || !newName[num] ? 'mina' : 'ali';
            return newName;
        });
    };

    return (
        <div>
            {parts.map((part, num) => {
                return (
                    <>
                        <Part name={name[num]} />
                        <button onClick={() => changeName(num)}>
                            changeName
                        </button>
                    </>
                );
            })}
            <hr />
            <button onClick={addPart}>add part</button>
        </div>
    );
};

const Part = ({ name = 'ali' }) => {
    return <h1>salam {name}</h1>;
};

export default ReportComparativeAdd;
