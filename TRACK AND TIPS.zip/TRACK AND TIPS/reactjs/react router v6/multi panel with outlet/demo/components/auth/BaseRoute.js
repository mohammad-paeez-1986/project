import { useCookies } from 'react-cookie';
import { Navigate } from 'react-router-dom';

const BaseRoute = () => {
    console.log('base');

    const [cookies, , removeCookie] = useCookies();
    const token = cookies['token'];
    const type = cookies['type'];

    if (!token) {
        return <Navigate to='/login' replace />;
    }

    if (!type) {
        removeCookie('token');
        return <Navigate to='/login' replace />;
    }

    if (type === 'admin') {
        return <Navigate to='/admin' replace />;
    }

    if (type === 'operator') {
        return <Navigate to='/operators' replace />;
    }

    removeCookie('token', { path: '/' });
    removeCookie('type', { path: '/' });

    return <Navigate to='/login' replace />;

    return <div>base</div>;
};

export default BaseRoute;
