import { useEffect } from 'react';
import { useCookies } from 'react-cookie';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [cookies, setCookie, removeCookie] = useCookies();
    const navigate = useNavigate();

    useEffect(() => {
        const token = cookies['token'];
        const type = cookies['type'];

        if (token) {
            if (type) {
                if (type === 'admin') {
                    navigate('/admin');
                } else if (type === 'operator') {
                    navigate('/operator');
                }
            } else {
                removeCookie('token', { path: '/' });
                removeCookie('type', { path: '/' });
            }
        }
    });
    const login = () => {
        setCookie('token', 'my-token', { path: '/' });
        setCookie('type', 'operator', { path: '/' });
    };

    return <button onClick={login}>Login</button>;
};

export default Login;
