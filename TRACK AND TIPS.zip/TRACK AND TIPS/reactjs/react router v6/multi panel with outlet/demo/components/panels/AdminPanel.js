import { useEffect } from 'react';
import { useCookies } from 'react-cookie';
import { Outlet, useNavigate } from 'react-router-dom';

const AdminPanel = () => {
    console.log('admin-panel');
    const [cookies, , removeCookie] = useCookies();
    const navigate = useNavigate();

    useEffect(() => {
        const token = cookies['token'];
        const type = cookies['type'];

        if (!token) {
            navigate('/login');
        }

        if (!type) {
            removeCookie('token', { path: '/' });
            navigate('/login');
        }

        if (type !== 'admin') {
            removeCookie('token', { path: '/' });
            removeCookie('type', { path: '/' });
            navigate('/login');
        }
    }, []);

    return (
        <>
            <div>AdminPanel</div>
            <hr />
            <Outlet />
        </>
    );
};

export default AdminPanel;
