import { useEffect } from 'react';
import { useCookies } from 'react-cookie';
import { Outlet, useNavigate, Link } from 'react-router-dom';

const OperatorPanel = () => {
    console.log('operator-panel');
    const [cookies, , removeCookie] = useCookies();
    const navigate = useNavigate();

    useEffect(() => {
        const token = cookies['token'];
        const type = cookies['type'];

        if (!token) {
            navigate('/login');
        }

        if (!type) {
            removeCookie('token', { path: '/' });
            navigate('/login');
        }

        if (type !== 'operator') {
            removeCookie('token', { path: '/' });
            removeCookie('type', { path: '/' });
            navigate('/login');
        }
    }, []);

    return (
        <>
            <div>OperatorPanel</div>
            <hr />
            <Outlet />
            <Link to='messages'>Messages</Link>
            <br />
            <Link to='tickets'>Tickets</Link>
        </>
    );
};

export default OperatorPanel;
