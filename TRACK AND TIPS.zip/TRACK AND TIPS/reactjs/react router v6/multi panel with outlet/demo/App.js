import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import BaseRoute from 'components/auth/BaseRoute';
import Login from 'components/auth/Login';
import AdminPanel from 'components/panels/AdminPanel';
import OperatorPanel from 'components/panels/OperatorPanel';

const App = () => {
    return (
        <Router>
            <Routes>
                <Route path='/' element={<BaseRoute />} />

                <Route path='/login' element={<Login />} />

                <Route path='admin/*' element={<AdminPanel />}>
                    <Route path='users' element={<h1>users</h1>} />
                    <Route path='orders' element={<h1>orders</h1>} />
                    <Route path='*' element={<h1>Not found</h1>} />
                </Route>

                <Route path='operator/*' element={<OperatorPanel />}>
                    <Route path='messages' element={<h1>Messages</h1>} />
                    <Route path='tickets' element={<h1>Tickets</h1>} />
                    <Route path='*' element={<h1>Not found</h1>} />
                </Route>

                <Route path='*' element={<h1>Not found</h1>} />
            </Routes>
        </Router>
    );
};

export default App;
