// with hook
import { useCookies } from 'react-cookie';
const [cookies, setCookie, removeCookie] = useCookie(['token']);
// -- use
cookies['token'];

// without hook //
import { Cookies } from 'react-cookie';
const cookies = new Cookie();
// cookies.set, cookies.set and ..

// remove cookie if not remove
removeCookie('token', { path: '/' });
