import React, { useState, useEffect } from "react";

import {
    Card,
    Row,
    Col,
    Form,
    Input,
    Button,
    Radio,
    Upload,
    Switch,
    Spin,
    Modal,
    Divider,
    Space,
    Tag,
    Tooltip,
    Alert,
} from "antd";
import {
    ArrowLeftOutlined,
    PlusOutlined,
    CloseCircleOutlined,
    CheckCircleOutlined,
} from "@ant-design/icons";
import axios from "axios";

import Notify from "../helpers/Notify.js";

function getBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = (error) => reject(error);
    });
}

const { TextArea } = Input;

const AddMedicalTest = ({ history }) => {
    // const [done, setDone] = useState(false);
    const [previewVisible, setPreviewVisible] = useState(false);
    const [previewImage, setPreviewImage] = useState("");
    const [previewTitle, setPreviewTitle] = useState("");
    const [, setUploading] = useState(false);
    const [fileList, setFieldList] = useState([]);
    const [spinning, setSpinning] = useState(false);
    const [emergencyPrice, setEmergencyPrice] = useState(0);
    const [specialPrice, setSpecialPrice] = useState(0);
    const [imagesPrice, setImagesPrice] = useState(0);
    const [costObject, setCostObject] = useState({
        emergency_amount: false,
        special_multiple: false,
        imageCount: 0,
    });
    const [price, setPrice] = useState(0);
    const [radio] = useState("1");

    const handleCancel = () => setPreviewVisible(false);

    const handlePreview = async (file) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj);
        }
        setPreviewImage(file.url || file.preview);
        setPreviewTitle(
            file.name || file.url.substring(file.url.lastIndexOf("/") + 1)
        );
        setPreviewVisible(true);
    };

    useEffect(() => {
        axios.get(`medicalTestsCosts`).then((result) => {
            setCostObject(result);
            console.log(result);
        });
    }, []);

    const getEmergencyPrice = (e) => {
        let pr = e ? costObject.emergency_amount : 0;
        setEmergencyPrice(pr);
    };

    const getSpecialPrice = (e) => {
        let pr = e ? costObject.special_multiple : 0;
        setSpecialPrice(pr);
    };

    const handleChange = ({ fileList }) => {
        // alert("ss");
        let imageCount = fileList.length;
        setFieldList([...fileList]);
        setImagesPrice(getImagePrice(imageCount));
    };

    const getPrice = () => {
        let total = 0;
        if (imagesPrice > 0) {
            if (specialPrice) {
                total = (emergencyPrice + imagesPrice) * specialPrice;
            } else {
                total = emergencyPrice + imagesPrice;
            }
        } else {
            total = 0;
        }
        // let balanceEnough = null;
        // if (total > 0) {
        //     if (costObject.balance >= total) {
        //         const color = "green";
        //         const text = (
        //             <>
        //                 <CheckCircleOutlined /> موجودی کافی
        //             </>
        //         );
        //         balanceEnough = (
        //             <Tag size="large" color={color}>
        //                 {text}
        //             </Tag>
        //         );
        //     } else {
        //         const color = "orange";
        //         const text = (
        //             <>
        //                 <CloseCircleOutlined /> موجودی ناکافی
        //             </>
        //         );
        //         balanceEnough = (
        //             <Tag size="large" color={color}>
        //                 {text}
        //             </Tag>
        //         );
        //     }
        // }
        return (
            <div className="price-place">
                {total > 0 && (
                    <Tag color="blue" style={{ fontSize: 14 }}>
                        {window.formatNumber(total) + " تومان"}
                    </Tag>
                )}
            </div>
        );
    };

    const getImagePrice = (imageCount) => {
        let pr = 0;
        switch (true) {
            case imageCount === 1:
                pr = costObject.image_one;
                break;
            case imageCount === 2:
                pr = costObject.image_two + costObject.image_one;
                break;
            case imageCount >= 3:
                pr =
                    (imageCount - 2) * costObject.other_images +
                    costObject.image_one +
                    costObject.image_two;
                break;
        }

        return pr;
    };

    const handleUpload = (values) => {
        setSpinning(true);
        values.emergency = !values.emergency ? 0 : 1;
        values.special = !values.special ? 0 : 1;
        const formData = new FormData();
        for (var [k, v] of Object.entries(values)) {
            if (v === undefined) v = "";
            formData.append(k, v);
        }

        fileList.forEach((file) => {
            formData.append("images[]", file.originFileObj);
        });

        // https://stackoverflow.com/a/54855963

        setUploading(true);

        window.headers = {
            "content-type": "multipart/form-data",
        };

        axios
            .post("medicalTests", formData)
            .then((result) => {
                // history.push({
                //     pathname: "/medical-tests/add/success",
                //     state: { item: result },
                // });
                // if result.status !== 3 send to bank
                console.log(result);
            })
            .catch((err) => {
                Notify.error(err);
                setSpinning(false);
            });
    };

    const props = {
        onRemove: (file) => {
            if (fileList.length === 1) setImagesPrice(0);
            setFieldList(() => {
                const index = fileList.indexOf(file);
                const newFileList = fileList.slice();
                newFileList.splice(index, 1);

                return newFileList;
            });
        },
        beforeUpload: (file) => {
            setFieldList([...fileList, file]);
            return false;
        },
        fileList,
    };

    const optionsWithDisabled = [
        { label: "مرد", value: "1" },
        { label: "زن", value: "0" },
    ];

    return (
        <Row align="center">
            <Col xs={24} sm={24} md={22} lg={18} xl={14}>
                <Form
                    onFinish={handleUpload}
                    scrollToFirstError={true}
                    initialValues={{
                        gender: "1",
                    }}
                >
                    <Card
                        title="ارسال آزمایش جدید"
                        extra={
                            <ArrowLeftOutlined
                                style={{
                                    fontSize: 20,
                                    fontWeight: "bold",
                                }}
                                onClick={() => history.goBack()}
                            />
                        }
                    >
                        <Spin
                            spinning={spinning}
                            size="large"
                            tip={
                                <>
                                    <br />

                                    <Alert
                                        message={
                                            <span
                                                style={{
                                                    fontSize: 13,
                                                    color: "#678",
                                                }}
                                            >
                                                تصاویر آزمایش در حال بارگذاری
                                                هستند، لطفا منتظر بمانید
                                            </span>
                                        }
                                        style={{ display: "inline-block" }}
                                        type="info"
                                    />
                                </>
                            }
                            // tip=""
                        >
                            <div className="add-form-fields">
                                <Row>
                                    <Form.Item
                                        name="age"
                                        label="سن"
                                        wrapperCol={{ span: 14 }}
                                        className="required"
                                        normalize={(value) =>
                                            value.toEnglishDigits()
                                        }
                                        rules={[
                                            {
                                                required: true,
                                                max: 120,
                                                min: 1,
                                            },
                                        ]}
                                    >
                                        <Input
                                            suffix={window.required}
                                            size="large"
                                            placeholder="سن"
                                            maxLength="3"
                                        />
                                    </Form.Item>
                                    <Form.Item
                                        name="gender"
                                        label="جنسیت"
                                        rules={[
                                            {
                                                required: true,
                                            },
                                        ]}
                                    >
                                        <Radio.Group
                                            value={1}
                                            size="large"
                                            optionType="button"
                                            options={optionsWithDisabled}
                                        />
                                    </Form.Item>
                                </Row>

                                <Row>
                                    <Tooltip
                                        placement="topLeft"
                                        title={
                                            "تفسیر اورژانسی شامل " +
                                            window.formatNumber(
                                                costObject.emergency_amount
                                            ) +
                                            " تومان هزینه بیشتر است"
                                        }
                                    >
                                        <Form.Item
                                            label=""
                                            name="emergency"
                                            style={{ marginLeft: 10 }}
                                        >
                                            <Switch
                                                onChange={(e) =>
                                                    getEmergencyPrice(e)
                                                }
                                                checkedChildren="اورژانسی"
                                                unCheckedChildren="غیر اورژانسی"
                                            />
                                        </Form.Item>
                                    </Tooltip>
                                    <Tooltip
                                        placement="topLeft"
                                        title={"هزینه پزشک متخصص بیشتر است"}
                                    >
                                        <Form.Item name="special">
                                            <Switch
                                                onChange={(e) =>
                                                    getSpecialPrice(e)
                                                }
                                                checkedChildren="پزشک متخصص"
                                                unCheckedChildren="پزشک عمومی"
                                            />
                                        </Form.Item>
                                    </Tooltip>
                                </Row>
                                <Form.Item name="reason" label="هدف آزمایش">
                                    <Input.TextArea
                                        rows={2}
                                        placeholder="چرا آزمایش داده‌اید؟ مثلا چکاپ، دیابت و ..."
                                        maxLength="255"
                                    ></Input.TextArea>
                                </Form.Item>
                                <Form.Item name="description" label="توضیحات">
                                    <TextArea
                                        placeholder="سوابق بیماری و دارو‌های مصرفی خود و هر سوالی دارید: مثلا وارفارین و استامینوفن مصرف می‌کنم. دیشب 4 حبه سیر با ماست خوردم و یک بار این هفته خون دماغ شدم"
                                        rows={3}
                                        maxLength="1000"
                                    ></TextArea>
                                </Form.Item>

                                <div className="clearfix">
                                    <Divider orientation="right">
                                        بارگذاری تصاویر آزمایش (حجم مجاز هر
                                        تصویر ۴ مگابایت)
                                    </Divider>
                                    <Upload
                                        {...props}
                                        listType="picture-card"
                                        fileList={fileList}
                                        onPreview={handlePreview}
                                        onChange={handleChange}
                                    >
                                        <PlusOutlined />
                                    </Upload>

                                    <Modal
                                        visible={previewVisible}
                                        title={previewTitle}
                                        footer={null}
                                        onCancel={handleCancel}
                                    >
                                        <img
                                            alt="example"
                                            style={{ width: "100%" }}
                                            src={previewImage}
                                        />
                                    </Modal>
                                </div>
                            </div>
                            <div className="ant-card-footer">
                                {getPrice()}
                                <Form.Item>
                                    <Button
                                        className="submit-button"
                                        type="primary"
                                        htmlType="submit"
                                    >
                                        ثبت و پرداخت
                                    </Button>
                                </Form.Item>
                            </div>
                        </Spin>
                    </Card>
                </Form>
            </Col>
        </Row>
    );
};

export default AddMedicalTest;
