import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Result, Tag, Spin, Button } from "antd";
import axios from "axios";
import Notify from "../helpers/Notify.js";
import UnpaidMedicalTest from "./UnpaidMedicalTest";

const PaymentResponse = () => {
    const [spinning, setSpinning] = useState(true);
    const [confirmed, setConfirmed] = useState(false);
    const [data, setData] = useState({});

    var query = new URLSearchParams(useLocation().search);

    const refreshBalance = (balance) => {
        // alert(balance);
        setData({ ...data, balance: window.formatNumber(balance) });
    };
    useEffect(() => {
        const status = query.get("status");
        if (status !== "10") {
            setSpinning(false);
            return;
        }

        axios
            .post("confirmPayment", {
                transaction_id: query.get("id"),
            })
            .then((res) => {
                setData(res);
                setConfirmed(true);
                setSpinning(false);
            })
            .catch((err) => {
                setData({
                    amount: 1000,
                    balance: 90000,
                });
                setConfirmed(true);

                setSpinning(false);
            });
    }, []);

    return (
        <>
            <Spin spinning={spinning}>
                {!spinning ? (
                    confirmed ? (
                        <>
                            <Result
                                style={{ padding: 70, marginTop: -70 }}
                                status="success"
                                title="حساب شما با موفقیت شارژ شد"
                                extra={[
                                    <>
                                        <Tag className="padding-10">
                                            مبلغ پرداختی:{" "}
                                            {window.formatNumber(data.amount)}{" "}
                                            تومان
                                        </Tag>
                                        <br />
                                        <br />
                                        <Tag className="padding-10">
                                            موجودی حساب:{" "}
                                            {window.formatNumber(data.balance)}{" "}
                                            تومان
                                        </Tag>
                                    </>,
                                ]}
                            />
                            <UnpaidMedicalTest
                                refreshBalance={refreshBalance}
                            />
                        </>
                    ) : (
                        <Result
                            status="error"
                            title="403"
                            title="بروز خطا در پرداخت"
                        />
                    )
                ) : (
                    <></>
                )}
            </Spin>
        </>
    );
};

export default PaymentResponse;
