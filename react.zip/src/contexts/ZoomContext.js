import { createContext } from 'react';
export const ZoomContext = createContext(2.5);
