import { useEffect } from 'react';
import AdminBase from 'components/panels/admin/AdminBase';
import Login from 'components/auth/Login';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import BaseRoot from 'components/common/BaseRoot';
import NotFound from 'components/common/NotFound';
import AdminWelcome from 'components/panels/admin/AdminWelcome';
import OperatorList from 'components/panels/admin/operator/OperatorList';
import TariffList from 'components/panels/admin/tariff/TariffList';
import DiscountSelect from 'components/panels/admin/discount/DiscountSelect';
import ConfigList from 'components/panels/admin/config/ConfigList';
import PriorityList from 'components/panels/admin/priority/PriorityList';
import LocativeGroupList from 'components/panels/admin/locative-group/LocativeGroupList';
import MessageList from 'components/panels/admin/message/MessageList';
import PlateSearch from 'components/panels/admin/car/PlateSearch';
import StatisticsShow from 'components/panels/admin/statistic/StatisticsShow';

// operators
import OperatorBase from 'components/panels/operators/layout/OperatorBase';
import EntranceExitList from 'components/panels/operators/entrance-exit/EntranceExitList';
import ReservationList from 'components/panels/operators/reservation/ReservationList';
import ConsiderationList from 'components/panels/operators/consideration/ConsiderationList';
import ProfileList from 'components/panels/operators/profile/ProfileList';
import MapShow from 'components/panels/operators/map/MapShow';
import ReportSelect from 'components/panels/operators/report/ReportSelect';
import ReportShow from 'components/panels/operators/report/ReportShow';

// users
import SearchCar from 'components/panels/users/search/SearchCar';
import SearchCarResult from 'components/panels/users/search/SearchCarResult';

const App = () => {
    // document.documentElement.style.setProperty('--animate-duration', '.5s');

    return (
        <Router basename='/parking'>
            <Routes>
                {/* not found */}
                <Route path='*' element={<NotFound />} />
                {/* baseRoot url '/' */}
                <Route path='/' element={<BaseRoot />} />

                {/* admin routes */}
                <Route path='/admin/*' element={<AdminBase />}>
                    <Route index element={<AdminWelcome />} />
                    <Route path='operators' element={<OperatorList />} />
                    <Route path='tariffs' element={<TariffList />} />
                    <Route path='discounts' element={<DiscountSelect />} />
                    <Route path='statistics' element={<ProfileList />} />
                    <Route path='config-files' element={<ConfigList />} />
                    <Route
                        path='locative-groups'
                        element={<LocativeGroupList />}
                    />
                    <Route path='messages' element={<MessageList />} />
                    <Route path='plate-search' element={<PlateSearch />} />
                    <Route path='statistics' element={<StatisticsShow />} />
                </Route>

                {/* operator routes */}
                <Route path='/operators/*' element={<OperatorBase />}>
                    <Route index element={<AdminWelcome />} />
                    <Route
                        path='entrance-exits'
                        element={<EntranceExitList />}
                    />
                    <Route path='reservations' element={<ReservationList />} />
                    <Route
                        path='considerations'
                        element={<ConsiderationList />}
                    />
                    <Route path='profiles' element={<ProfileList />} />
                    <Route path='discounts' element={<DiscountSelect />} />
                    <Route path='messages' element={<MessageList />} />
                    <Route path='maps' element={<MapShow />} />
                    <Route path='reports' element={<ReportSelect />} />
                    <Route path='report-show' element={<ReportShow />} />
                </Route>

                {/* user routes */}
                <Route path='/user/search-car' element={<SearchCar />}></Route>
                <Route
                    path='user/search-car-result'
                    element={<SearchCarResult />}
                ></Route>

                <Route path='/login' element={<Login />} />
            </Routes>
        </Router>
    );
};

export default App;
