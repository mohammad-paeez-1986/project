import React, { useState, useEffect } from 'react';
import { Badge, Dropdown, List } from 'antd';
import { MailOutlined } from '@ant-design/icons';

const MessageMenu = () => {
    const [notificationList, setNotificationList] = useState([]);
    const [newNotificationCount, setNewNotificationCount] = useState(0);

    useEffect(() => {
        console.log('socket');
        var socket = new WebSocket(
            'ws://194.5.175.154:8000/fa/ws/notifications/'
        );
        socket.addEventListener('open', () => {
            console.log('open');
        });
        socket.addEventListener('message', (e) => {
            setNotificationList((prev) => [...prev, e.data]);
            setNewNotificationCount((prev) => prev + 1);
            console.log(e.data);
        });
        console.log('sss');
        // return () => WebSocket.close();
    }, []);

    const onVisibleChange = (e) => {
        if (e) {
            setNewNotificationCount(0);
        }
    };

    return (
        <Dropdown
            overlay={
                <List
                    bordered
                    dataSource={notificationList.slice(0, 10)}
                    renderItem={(item) => <List.Item>{item}</List.Item>}
                    className='notification-list'
                />
            }
            trigger='click'
            className='pointer'
            onVisibleChange={onVisibleChange}
            arrow
        >
            <Badge count={newNotificationCount}>
                <MailOutlined />
            </Badge>
        </Dropdown>
    );
};

export default React.memo(MessageMenu);
