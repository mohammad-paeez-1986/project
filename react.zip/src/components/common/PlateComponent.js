import { Input, Select, Form } from 'antd';
import { numbers, cityNumbers, alphabet } from 'helpers/plate';
const { Option } = Select;

const PlateComponent = () => {
    return (
        <Form.Item label=''>
            <p className='plate-select-iran'>ایران</p>
            <div className='plate'>
                <Input.Group compact>
                    <Form.Item name={['plate', 'p1']} noStyle>
                        <Select
                            placeholder='--'
                            style={{
                                background: '#f6f6f6',
                                width: 44,
                            }}
                            bordered={false}
                            showArrow={false}
                        >
                            <Option value={'@@'}>@@</Option>
                            {cityNumbers.map((item) => (
                                <Option value={item}>{item}</Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item
                        name={['plate', 'p2']}
                        noStyle
                        rules={[
                            {
                                required: true,
                                message: '',
                            },
                        ]}
                    >
                        <Select
                            placeholder='--'
                            style={{
                                background: '#fff',
                                width: 35,
                            }}
                            bordered={false}
                            showArrow={false}
                        >
                            <Option value={'@'}>@</Option>
                            {numbers.map((item) => (
                                <Option value={item}>{item}</Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item
                        name={['plate', 'p3']}
                        noStyle
                        rules={[
                            {
                                required: true,
                                message: '',
                            },
                        ]}
                    >
                        <Select
                            placeholder='--'
                            style={{
                                background: '#fff',
                                width: 35,
                            }}
                            bordered={false}
                            showArrow={false}
                        >
                            <Option value={'@'}>@</Option>
                            {numbers.map((item) => (
                                <Option value={item}>{item}</Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item
                        name={['plate', 'p4']}
                        noStyle
                        rules={[
                            {
                                required: true,
                                message: '',
                            },
                        ]}
                    >
                        <Select
                            placeholder='--'
                            style={{
                                background: '#fff',
                                width: 35,
                            }}
                            bordered={false}
                            showArrow={false}
                        >
                            <Option value={'@'}>@</Option>
                            {numbers.map((item) => (
                                <Option value={item}>{item}</Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item
                        name={['plate', 'p5']}
                        noStyle
                        rules={[
                            {
                                required: true,
                                message: '',
                            },
                        ]}
                    >
                        <Select
                            placeholder='--'
                            style={{
                                background: '#fff',
                                width: 47,
                            }}
                            bordered={false}
                            showArrow={false}
                        >
                            <Option value={'@@'}>@@</Option>
                            {alphabet.map((item) => (
                                <Option value={item.value}>{item.title}</Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item
                        name={['plate', 'p6']}
                        noStyle
                        rules={[
                            {
                                required: true,
                                message: '',
                            },
                        ]}
                    >
                        <Select
                            placeholder='--'
                            style={{
                                background: '#fff',
                                width: 35,
                            }}
                            bordered={false}
                            showArrow={false}
                        >
                            <Option value={'@'}>@</Option>
                            {numbers.map((item) => (
                                <Option value={item}>{item}</Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item
                        name={['plate', 'p7']}
                        noStyle
                        rules={[
                            {
                                required: true,
                                message: '',
                            },
                        ]}
                    >
                        <Select
                            placeholder='--'
                            style={{
                                background: '#fff',
                                width: 35,
                            }}
                            bordered={false}
                            showArrow={false}
                        >
                            <Option value={'@'}>@</Option>
                            {numbers.map((item) => (
                                <Option value={item}>{item}</Option>
                            ))}
                        </Select>
                    </Form.Item>
                </Input.Group>
            </div>
        </Form.Item>
    );
};

export default PlateComponent;
