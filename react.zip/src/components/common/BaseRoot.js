import { useCookies } from 'react-cookie';
import { Navigate } from 'react-router-dom';

const BaseRoot = () => {
    console.log('baseRoot');

    const [cookies, , removeCookie] = useCookies();
    const token = cookies['token'];
    const type = cookies['type'];

    if (!token) {
        return <Navigate to='/login' replace />;
    }

    if (!type) {
        removeCookie('token');
        return <Navigate to='/login' replace />;
    }

    if (type === 'admin') {
        return <Navigate to='/admin' replace />;
    }

    if (type === 'operator') {
        return <Navigate to='/operators' replace />;
    }

    removeCookie('token');
    removeCookie('type');

    return <Navigate to='/login' replace />;
};

export default BaseRoot;
