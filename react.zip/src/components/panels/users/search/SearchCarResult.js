import React, { useState, useEffect } from 'react';
import {
    MapContainer,
    LayersControl,
    GeoJSON,
    useMapEvent,
} from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import config from 'config/geoserver.json';
import t from 'helpers/translation';
import { useNavigate, useLocation } from 'react-router-dom';
import { Empty, Card, Image } from 'antd';
import { ArrowLeftOutlined, FileImageOutlined } from '@ant-design/icons';
import { numberToPlate } from 'helpers/plate';

import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

const SearchCarResult = () => {
    const [map, setMap] = useState(null);
    const [featuresList, setFeaturesList] = useState([]);
    const [zoomControl, setZoomControl] = useState(false);
    const [highlightList, setHighlightList] = useState([]);
    const [center, setCenter] = useState([
        19.897240250321865, 432.57545592420996,
    ]);

    const { state } = useLocation();
    const { data } = state;
    // const [data, setData] = useState(state.data);

    const navigate = useNavigate();

    const SetLayerOptions = (name) => {
        if (name.substr(0, 6) === 'camera') {
            name = 'camera';
        }

        L.Marker.prototype.options.icon = L.icon({
            iconUrl: process.env.PUBLIC_URL + '/assets/images/' + name + '.png',
        });
    };

    // set floors and default icon
    useEffect(() => {
        loadLayers(data.parking_spot_detail.properties_floor);
    }, []);

    const loadLayers = async (floorNum) => {
        const floor = await config.shape_files.find(
            (item) => item.floor == floorNum
        );

        let layers;
        if (floor) {
            layers = Object.values(floor.layers);
        } else {
            return;
        }

        if (layers && layers.length > 0) {
            setFeaturesList([]);
            layers.map((layer) => {
                if (layer !== 'fisheye') {
                    fetch(
                        `http://194.5.175.154:8090/geoserver/${floor.workspace.trim()}/wfs?outputFormat=application/json&request=GetFeature&service=WFS&typeName=parsis:${layer}&version=1.0.0`
                    )
                        .then((res) => res.json())
                        .then((res) => {
                            let features = res.features;

                            features = features.map((item) => {
                                item.properties.tooltipContent = item.id;
                                return item;
                            });

                            // add icon
                            SetLayerOptions(layer);

                            setFeaturesList((featuresList) => [
                                ...featuresList,
                                { [layer]: features },
                            ]);
                        })
                        .catch((e) => {
                            console.log(e);
                        });
                }
            });
        }
    };

    function onEachFeature(feature, layer) {
        if (feature.properties) {
            if (feature.properties?.tooltipContent) {
                layer.bindTooltip(feature.properties?.tooltipContent);
            }

            if (
                feature.properties.Layer === 'parking' &&
                feature.properties.OBJECTID ==
                    data.parking_spot_detail.properties_id
            ) {
                try {
                    const cordinate = feature.geometry.coordinates[0][0][0];

                    map?.setView([cordinate[1], cordinate[0]], 4);
                } catch (error) {
                    console.log(error);
                }
            }
        }
    }

    return (
        <Card
            title={
                <div className='car-detail'>
                    <div>
                        <span className='detail-title'>
                            {t('plate_number')}:
                        </span>
                        <span className='detail-value'>
                            {numberToPlate(data.car_plate)}
                        </span>
                    </div>

                    <div>
                        <span className='detail-title'>{t('floor')}:</span>
                        <span className='detail-value'>
                            {data.parking_spot_detail.properties_floor}
                        </span>
                    </div>

                    <div>
                        <span className='detail-title'>
                            {t('parking_spot_id')}:
                        </span>
                        <span className='detail-value'>
                            {data.parking_spot_detail.properties_id}
                        </span>
                    </div>
                    <div>
                        <span className='detail-title'>{t('last_pic')}:</span>
                        <span className='detail-value'>
                            <Image
                                placeholder={
                                    <FileImageOutlined className='icon-link icon-edit float-left' />
                                }
                                preview={{
                                    src: 'http://' + data.get_last_pic,
                                }}
                            />
                        </span>
                    </div>
                </div>
            }
            extra={[
                <ArrowLeftOutlined
                    onClick={() => navigate('/user/search-car')}
                />,
            ]}
        >
            <MapContainer
                id='map'
                ref={setMap}
                zoom={4}
                center={[19.897240250321865, 432.57545592420996]}
            >
                {featuresList && featuresList.length > 0 ? (
                    <LayersControl position={'topleft'}>
                        {featuresList.map((features) => (
                            <LayersControl.Overlay
                                checked
                                // key={Object.keys(features)[0].id}
                                name={Object.keys(features)[0]}
                            >
                                <GeoJSON
                                    data={Object.values(features)[0]}
                                    // markersInheritOptions={true}
                                    onEachFeature={onEachFeature}
                                    style={(s) => {
                                        if (
                                            (s.properties.Layer === 'parking' &&
                                                s.properties.OBJECTID ==
                                                    data.parking_spot_detail
                                                        .properties_id) ||
                                            (s?.id.substr(0, 5) === 'route' &&
                                                s?.properties.Id ==
                                                    data.parking_spot_detail
                                                        .corridor)
                                        ) {
                                            // console.log(s.properties);
                                            return {
                                                color: '#f00',
                                            };
                                        } else {
                                            return {
                                                color: 'rgb(51, 136, 255)',
                                            };
                                        }
                                    }}
                                />
                            </LayersControl.Overlay>
                        ))}
                    </LayersControl>
                ) : (
                    <Empty className='map-placeholder' />
                )}
            </MapContainer>
        </Card>
    );
};

export default SearchCarResult;
