import React, { useState } from 'react';
import { Spin, Col, Card, Form, Button } from 'antd';
import { useNavigate } from 'react-router-dom';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import PlateComponent from 'components/common/PlateComponent';
import PlateComp from 'components/common/PlateComp';

const SearchCar = () => {
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const onFinish = async (values) => {
        try {
            const plate = Object.values(values.plate).reverse().join('');

            const { results } = await axios.get(
                `general/search_car_for_driver/?car__plate_number=${plate}`
            );

            console.log(results);

            if (results.length && results[0]?.parking_spot_detail) {
                console.log(results[0]);
                navigate('/user/search-car-result', { state: { data: results[0] } });
            } else {
                notify.danger(t('nothing_found'));
            }
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <div className='search-car-wrapper'>
            <Col xs={22} sm={18} md={16} xl={12}>
                <Spin spinning={loading}>
                    <div className='search-car-content'>
                        <p className='large-description'>{t('search_car')}</p>
                        <p className='small-description text-center'>
                            {t('search_car_hint')}
                        </p>
                        <Form onFinish={onFinish}>
                            {/* <PlateComponent /> */}
                            <PlateComp />
                            <br /><br />
                            <Form.Item
                                colon={false}
                                style={{ textAlign: 'center' }}
                            >
                                <Button
                                    type='primary'
                                    htmlType='submit'
                                    className='full-button'
                                >
                                    {t('search')}
                                </Button>
                            </Form.Item>
                        </Form>
                        <div className='search-img'>
                            <img
                                src='/assets/images/search.svg'
                                alt='search-car'
                            />
                        </div>
                        <div className='circle circle2 circle2-top'></div>
                        <div className='circle circle1 circle1-top'></div>
                        <div className='circle circle2 circle2-bottom'></div>
                        <div className='circle circle1 circle1-bottom'></div>
                    </div>
                </Spin>
            </Col>
        </div>
    );
};

export default SearchCar;
