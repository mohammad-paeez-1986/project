import { useState, useEffect } from 'react';
import t from 'helpers/translation';
import { Table, Card, Popconfirm, Button, Upload } from 'antd';
import {
    
    DeleteOutlined,
    DownloadOutlined,
    UploadOutlined,
} from '@ant-design/icons';
import { formatDate } from 'helpers/generalHelpers';
import axios from 'axios';
import notify from 'helpers/notify';
import { useCookies } from 'react-cookie';
import useData from 'hooks/useData';

const ConfigList = () => {
    const { data, loading, total, pageSize, onChange, getData, setData } =
        useData('configurations/configurations/');
    const [uploadButtonLoading, setUploadButtonLoading] = useState(false);
    const [cookies] = useCookies();

    const columns = [
        {
            title: t('file_name'),
            render: ({ file_name }) => file_name.substr(14).substring(1),
        },
        {
            title: t('download'),
            render: ({ config }) => (
                <a href={config} target='_blank'>
                    <DownloadOutlined className='icon-link' />
                </a>
            ),
        },
        {
            title: t('upload_date'),
            render: ({ upload_date }) => formatDate(upload_date),
        },
        {
            title: t('delete'),
            render: (row) => {
                return (
                    <Popconfirm
                        title={t('are_you_sure')}
                        onConfirm={() => remove(row.id)}
                    >
                        <DeleteOutlined className='icon-link icon-danger' />
                    </Popconfirm>
                );
            },
        },
    ];

    const props = {
        name: 'config',
        action:
            process.env.REACT_APP_API_URL + 'configurations/configurations/',
        headers: {
            authorization: 'Token ' + cookies['token'],
        },
        showUploadList: false,
        maxCount: 1,
        onChange(info) {
            if (info.file.status !== 'uploading') {
                // console.log(info.file, info.fileList);
            }
            if (info.file.status === 'done') {
                getData();
                notify.success(t('file_uploaded_successfully'));
            } else if (info.file.status === 'error') {
                console.log(info);
                notify.danger(info.file.response.message);
            }
        },
    };

    const remove = async (id) => {
        try {
            await axios.delete(`configurations/configurations/${id}/`);

            // remove from data
            const updatedData = data.filter((item) => item.id !== id);
            setData(updatedData);
        } catch (error) {
            notify.danger(error);
        }
    };

    return (
        <div className='fill-page'>
            <Card
                title={t('config_file')}
                extra={
                    <Upload {...props}>
                        <Button
                            icon={<UploadOutlined />}
                            loading={uploadButtonLoading}
                        >
                            {/* {t('upload_new_file')} */}
                        </Button>
                    </Upload>
                }
            >
                <Table
                    loading={loading}
                    dataSource={data}
                    columns={columns}
                    rowKey={(record) => record.id}
                    scroll={{ x: true }}
                    pagination={{
                        total,
                        pageSize,
                        hideOnSinglePage: true,
                        onChange,
                    }}
                />
            </Card>
        </div>
    );
};

export default ConfigList;
