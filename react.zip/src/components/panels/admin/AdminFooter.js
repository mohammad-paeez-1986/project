import React from 'react';
import { Layout } from 'antd';
const { Footer } = Layout;

const AdminFooter = () => {
    console.log('footer');
    return <Footer className='footer'>Parking</Footer>;
};

export default React.memo(AdminFooter);
