import React from 'react';
import t from 'helpers/translation';

const AdminWelcome = () => {
    return (
        <div className='admin-welcome'>
            <img src='/assets/images/admin-panel.svg' />
            <p>{t('admin_welcome')}</p>
        </div>
    );
};

export default AdminWelcome;
