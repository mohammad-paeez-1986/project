import React, { useState, useEffect } from 'react';
import { Table } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import useData from 'hooks/useData';
import { formatNumber, formatDate } from 'helpers/generalHelpers';
import { numberToPlate } from 'helpers/plate';

const PlateSearchResult = ({ plate }) => {
    const [plateNum, setPlateNum] = useState(plate);
    const columns = [
        {
            title: t('plate_number'),
            render: ({ car_plate }) => <span>{numberToPlate(car_plate)}</span>,
            width:150,
            className:'small-font'
        },
        {
            title: t('parking_spot_detail'),
            render: ({ parking_spot_detail }) => parking_spot_detail || '-',
        },
        {
            title: t('price'),
            render: ({ price }) => (price ? formatNumber(price) : '-'),
        },
        {
            title: t('discount'),
            render: ({ discount }) => discount || '-',
        },
        {
            title: t('enter_time'),
            render: ({ enter_time }) =>
                enter_time ? formatDate(enter_time) : '-',
        },
        {
            title: t('exit_time'),
            render: ({ exit_time }) =>
                exit_time ? formatDate(exit_time) : '-',
        },
        {
            title: t('np_group'),
            dataIndex: 'np_group',
        },
        {
            title: t('locative_group'),
            render: ({ locative_group }) => locative_group || '-',
        },
        {
            title: t('car_descriptions'),
            render: ({ car_descriptions }) => car_descriptions?.text || '-',
        },
        {
            title: t('reservation'),
            render: ({ reservation }) => reservation || '-',
        },
    ];

    const { data, loading, total, pageSize, onChange, getData, setData } =
        useData(`general/search_car/?car__plate_number=${plate}`);

    useEffect(() => {
        getData();
    }, [plate]);

    return (
        <div>
            <Table
                loading={loading}
                dataSource={data}
                columns={columns}
                rowKey={(record) => record.id}
                scroll={{ x: true }}
                pagination={{
                    total,
                    pageSize,
                    hideOnSinglePage: true,
                    onChange,
                }}
            />
        </div>
    );
};

export default PlateSearchResult;
