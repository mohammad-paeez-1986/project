import React, { useState } from 'react';
import { Row, Card, Form, Button, Table } from 'antd';
import t from 'helpers/translation';
import PlateSearchResult from 'components/panels/admin/car/PlateSearchResult';
import PlateComp from 'components/common/PlateComp';
import axios from 'axios';
import notify from 'helpers/notify';


const PlateSearch = () => {
    const [plate, setPlate] = useState(null);

    const onFinish = (values) => {
        const { plate } = values;
        console.log(Object.values(plate).reverse().join(''));
        // let plateString = '';
        // for (let i in plate) {
        //     plateString += plate[i];
        // }
        // console.log(plateString)
        setPlate(Object.values(plate).reverse().join(''));
    };

    return (
        <div className='fill-page'>
            <Card title={t('plate_search')}>
                    <br /><br />
                <Row align='center'>
                    <Form
                        onFinish={onFinish}
                        // labelCol={{ span: 8 }}
                        // wrapperCol={{ span: 24 }}
                    >
                        <PlateComp />
                        <br /><br />
                        <Form.Item
                            colon={false}
                            style={{ textAlign: 'center' }}
                        >
                            <Button type='primary' htmlType='submit'>
                                {t('search')}
                            </Button>
                        </Form.Item>
                    </Form>
                </Row>
                {plate && <PlateSearchResult plate={plate} />}
            </Card>
        </div>
    );
};

export default PlateSearch;
