import { useEffect, useState } from 'react';
import { useCookies } from 'react-cookie';
import { Outlet, useNavigate } from 'react-router-dom';
import { Layout } from 'antd';
import AdminHeader from 'components/panels/admin/AdminHeader';
import AdminSider from 'components/panels/admin/AdminSider';
import AdminFooter from 'components/panels/admin/AdminFooter';

const { Content } = Layout;

const AdminBase = () => {
    console.log('admin-base');
    const [cookies, , removeCookie] = useCookies();
    const [collapsed, setCollapsed] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        const token = cookies['token'];
        const type = cookies['type'];

        if (!token) {
            navigate('/login');
        }

        if (!type) {
            removeCookie('token');
            navigate('/login');
        }

        if (type !== 'admin') {
            removeCookie('token');
            removeCookie('type');
            navigate('/login');
        }
    }, []);

    return (
        <>
            <Layout>
                <AdminSider collapsed={collapsed} toggle={setCollapsed} />
                <Layout>
                    <AdminHeader collapsed={collapsed} toggle={setCollapsed} />
                    <Content className='content'>
                        <Outlet />
                    </Content>
                    <AdminFooter />
                </Layout>
            </Layout>
        </>
    );
};

export default AdminBase;
