import { useState, useEffect } from 'react';
import { Row, Spin, Form, Input, Select, Button } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import {
    getNumericFormatted,
    formatNumber,
    unformat,
} from 'helpers/generalHelpers';

const { Option } = Select;

const TariffAdd = ({ refreshData, closeModal }) => {
    const [loading, setLoading] = useState(false);
    const [locativeGroupList, setLocativeGroupList] = useState([]);
    const [selectLoading, setSelectLoading] = useState(true);

    useEffect(async () => {
        try {
            const { results } = await axios.get('parking_spot/locative_group/');
            setSelectLoading(false);
            setLocativeGroupList(results);
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    const onFinish = async (values) => {
        values.entrance_price = unformat(values.entrance_price);
        values.hourly_price = unformat(values.hourly_price);

        setLoading(true);

        try {
            const data = await axios.post('parking_spot/fee/', values);

            setLoading(false);
            closeModal();
            refreshData();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <Row align='center'>
            <Spin spinning={loading}>
                <Form
                    labelCol={{ span: 7 }}
                    wrapperCol={{ span: 24 }}
                    onFinish={onFinish}
                    autoComplete='off'
                >
                    <Form.Item
                        label={t('title')}
                        name='title'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label={t('entrance_price')}
                        name='entrance_price'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                        normalize={(value) => getNumericFormatted(value)}
                    >
                        <Input placeholder={t('numeric_value')} />
                    </Form.Item>

                    <Form.Item
                        label={t('hourly_price')}
                        name='hourly_price'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                        normalize={(value) => getNumericFormatted(value)}
                    >
                        <Input placeholder={t('numeric_value')} />
                    </Form.Item>

                    <Form.Item
                        name='locative_group'
                        label={t('locative_group_name')}
                        rules={[{ required: true }]}
                    >
                        <Select loading={selectLoading}>
                            {locativeGroupList.map((item) => {
                                return (
                                    <Option value={item.id} key={item.id}>
                                        {item.title}
                                    </Option>
                                );
                            })}
                        </Select>
                    </Form.Item>

                    <div className='modal-footer'>
                        <Form.Item>
                            <Button
                                type='primary'
                                htmlType='submit'
                                className='wide-button'
                            >
                                {t('add')}
                            </Button>
                        </Form.Item>
                    </div>
                </Form>
            </Spin>
        </Row>
    );
};

export default TariffAdd;
