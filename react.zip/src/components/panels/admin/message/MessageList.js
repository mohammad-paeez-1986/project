import { useState, useEffect } from 'react';
import t from 'helpers/translation';
import { Table, Card } from 'antd';
import { formatDate } from 'helpers/generalHelpers';
import useData from 'hooks/useData';

const MessageList = () => {
    const { data, loading, total, pageSize, onChange } =
        useData('log/system_logs/');

    const columns = [
        {
            title: t('title'),
            dataIndex: 'title',
        },
        {
            title: t('type'),
            dataIndex: 'type',
        },
        {
            title: t('access_level'),
            dataIndex: 'access_level',
        },
        {
            title: t('created_at'),
            render: ({ created_at }) => formatDate(created_at),
        },
    ];

    return (
        <div className='fill-page'>
            <Card title={t('messages')}>
                <Table
                    dataSource={data}
                    loading={loading}
                    columns={columns}
                    rowKey={(record) => record.id}
                    scroll={{ x: true }}
                    pagination={{
                        total,
                        pageSize,
                        hideOnSinglePage: true,
                        onChange,
                    }}
                />
            </Card>
        </div>
    );
};

export default MessageList;
