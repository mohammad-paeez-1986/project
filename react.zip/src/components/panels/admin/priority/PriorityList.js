import { useState, useEffect } from 'react';
import { Card, Table } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import {
    SortableContainer,
    SortableElement,
    SortableHandle,
} from 'react-sortable-hoc';
import { MenuOutlined } from '@ant-design/icons';
import { arrayMoveImmutable } from 'array-move';

const DragHandle = SortableHandle(() => (
    <MenuOutlined style={{ cursor: 'pointer', color: '#999' }} />
));

const columns = [
    {
        title: 'Sort',
        dataIndex: 'sort',
        width: 30,
        // className: 'drag-visible',
        render: () => <DragHandle />,
    },
    {
        title: 'title',
        dataIndex: 'title',
        // className: 'drag-visible',
    },
    // {
    //     title: 'Age',
    //     dataIndex: 'age',
    // },
    // {
    //     title: 'Address',
    //     dataIndex: 'address',
    // },
];

const SortableItem = SortableElement((props) => <tr {...props} />);
const SortableBody = SortableContainer((props) => <tbody {...props} />);

const PriorityList = () => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(async () => {
        try {
            const data = await axios.get('parking_spot/priority/');
            setLoading(false);
            const transformedData = data.results.map((item) => {
                return { ...item, index: item.priority };
            });
            setData(transformedData);
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    const onSortEnd = ({ oldIndex, newIndex }) => {
        if (oldIndex !== newIndex) {
            const newData = arrayMoveImmutable(
                [].concat(data),
                oldIndex,
                newIndex
            ).filter((el) => !!el);
            console.log('Sorted items: ', newData);
            setData(newData);
            // this.setState({ dataSource: newData });
        }
    };

    const DraggableContainer = (props) => (
        <SortableBody
            useDragHandle
            disableAutoscroll
            axis='y'
            helperClass='row-dragging'
            onSortEnd={onSortEnd}
            {...props}
        />
    );

    const DraggableBodyRow = ({ className, style, ...restProps }) => {
        // function findIndex base on Table rowKey props and should always be a right array index
        const index = data.findIndex(
            (x) => x.index === restProps['data-row-key']
        );
        return <SortableItem index={index} {...restProps} />;
    };

    return (
        <div className='fill-page'>
            <Card
                title={t('priority')}
                loading={loading}
                style={{ width: 500 }}
            >
                <Table
                    className='priority-table'
                    pagination={false}
                    dataSource={data}
                    columns={columns}
                    rowKey='index'
                    components={{
                        body: {
                            wrapper: DraggableContainer,
                            row: DraggableBodyRow,
                        },
                    }}
                />
            </Card>
        </div>
    );
};

export default PriorityList;
