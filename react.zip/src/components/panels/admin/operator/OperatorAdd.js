import { useState } from 'react';
import { Row, Spin, Form, Input, Button } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';

const OperatorAdd = ({ id, refreshData, closeModal }) => {
    const [loading, setLoading] = useState(false);

    const onFinish = async (values) => {
        setLoading(true);

        try {
            const data = await axios.post('users/', values);

            closeModal();
            refreshData();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <Row align='center'>
            <Spin spinning={loading}>
                <Form
                    labelCol={{ span: 7 }}
                    wrapperCol={{ span: 24 }}
                    onFinish={onFinish}
                    autoComplete='off'
                >
                    <Form.Item
                        label={t('username')}
                        name='username'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                    >
                        <Input className='input-ltr' />
                    </Form.Item>

                    <Form.Item
                        label={t('password')}
                        name='password'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                    >
                        <Input.Password />
                    </Form.Item>
                    <div className='modal-footer'>
                        <Form.Item>
                            <Button
                                type='primary'
                                htmlType='submit'
                                className='wide-button'
                            >
                                {t('add')}
                            </Button>
                        </Form.Item>
                    </div>
                </Form>
            </Spin>
        </Row>
    );
};

export default OperatorAdd;
