import { useState, useEffect } from 'react';
import { Row, Spin, Form, Input, Button } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';

const OperatorEdit = ({ rowData, refreshData, closeModal }) => {
    const [loading, setLoading] = useState(false);
    const [form] = Form.useForm();

    useEffect(() => {
        const { username } = rowData;

        form.setFieldsValue({
            username,
        });
    }, []);

    const onFinish = async (values) => {
        delete values.username
        setLoading(true);

        try {
            const id = rowData.id;
            const data = await axios.patch(`users/${id}/`, { id, ...values });

            setLoading(false);
            closeModal();
            refreshData();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <Row align='center'>
            <Spin spinning={loading}>
                <Form
                    form={form}
                    labelCol={{ span: 7 }}
                    wrapperCol={{ span: 24 }}
                    onFinish={onFinish}
                    autoComplete='off'
                >
                    <Form.Item
                        label={t('username')}
                        name='username'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                    >
                        <Input className='input-ltr' disabled/>
                    </Form.Item>

                    <Form.Item
                        label={t('password')}
                        name='password'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                    >
                        <Input.Password />
                    </Form.Item>
                    <div className='modal-footer'>
                        <Form.Item>
                            <Button
                                type='primary'
                                htmlType='submit'
                                className='wide-button'
                            >
                                {t('edit')}
                            </Button>
                        </Form.Item>
                    </div>
                </Form>
            </Spin>
        </Row>
    );
};

export default OperatorEdit;
