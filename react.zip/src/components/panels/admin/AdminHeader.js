import React, { useState, useEffect } from 'react';
import { Layout, Menu, Space, Select } from 'antd';
import {
    MenuUnfoldOutlined,
    MenuFoldOutlined,
    LogoutOutlined,
} from '@ant-design/icons';
import MessageMenu from 'components/common/MessageMenu';
import { useNavigate } from 'react-router-dom';
import { useCookies } from 'react-cookie';
import i18n from 'i18next';

const { Header } = Layout;
const { Option } = Select;

const AdminHeader = ({ collapsed, toggle }) => {
    const [cookies, setCookie, removeCookie] = useCookies();
    const navigate = useNavigate();

    const changeLanguage = (e) => {
        setCookie('lang', e);
        window.location.reload();
    };

    const logout = () => {
        removeCookie('token', { path: '/' });
        removeCookie('type', { path: '/' });

        navigate('/login', { replace: true });
    };

    return (
        <Header className='header'>
            {/* {React.createElement(
                collapsed ? MenuUnfoldOutlined : MenuFoldOutlined,
                {
                    className: 'trigger',
                    onClick: () => toggle(!collapsed),
                }
            )} */}
            <div className="left-icones header-icons">
            <Select
                    dropdownClassName='language-select'
                    className='language-select'
                    showArrow={false}
                    onChange={changeLanguage}
                    defaultValue={i18n.language}
                >
                    {i18n.languages.map((item) => (
                        <Option key={item} value={item}>
                            {item}
                        </Option>
                    ))}
                </Select>
            </div>
            <div className='header-icons'>
                {/* <Space size='large'> */}
                
                <MessageMenu />
                <LogoutOutlined
                    className='logout-icon icon-link'
                    onClick={logout}
                />
                {/* </Space> */}
            </div>
        </Header>
    );
};

export default React.memo(AdminHeader);
