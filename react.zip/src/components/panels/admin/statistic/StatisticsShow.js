import React from 'react'
import { numberToPlate } from "helpers/plate";

const StatisticsShow = () => {

    const n = numberToPlate(569843211)

  return (
    <div> {n}</div>
  )
}

export default StatisticsShow