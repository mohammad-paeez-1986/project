import React, { useState } from 'react';
import { Tabs } from 'antd';
import t from 'helpers/translation';
import DiscountNormalList from 'components/panels/admin/discount/normal/DiscountNormalList';
import DiscountBusinessList from 'components/panels/admin/discount/business/DiscountBusinessList';

const { TabPane } = Tabs;

const DiscountSelect = () => {
    const [activeTabKey, setActiveTabKey] = useState(null);

    const callback = (e) => {
        setActiveTabKey(e);
    };

    return (
        <Tabs
            activeKey={activeTabKey}
            onChange={callback}
            centered={true}
            type='card'
            size='small'
        >
            <TabPane tab={t('discount_normal')} key='1'>
                <DiscountNormalList />
            </TabPane>
            <TabPane tab={t('discount_business')} key='2'>
                <DiscountBusinessList />
            </TabPane>
        </Tabs>
    );
};

export default DiscountSelect;
