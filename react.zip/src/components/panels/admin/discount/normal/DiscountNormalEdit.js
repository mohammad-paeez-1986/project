import { useState, useEffect } from 'react';
import { Row, Spin, Form, Input, Select, Button } from 'antd';
import dayjs from 'dayjs';

import {
    DatePicker as DatePickerJalali,
    useJalaliLocaleListener,
} from 'antd-jalali';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import {
    getNumericFormatted,
    getNumeric,
    getPercent,
    formatNumber,
    unformat,
} from 'helpers/generalHelpers';
import { dateTimeToString } from 'helpers/generalHelpers';
import { numberToPlate , carListWithStringPlateNumber} from 'helpers/plate';

const { Option } = Select;
const { TextArea } = Input;

const DiscountNormalEdit = ({ rowData, refreshData, closeModal }) => {
    useJalaliLocaleListener();

    const [loading, setLoading] = useState(false);
    const [locativeGroupList, setLocativeGroupList] = useState([]);
    const [carsList, setCarsList] = useState([]);
    const [locativeGroupSelectLoading, setlocativeGroupSelectLoading] =
        useState(false);
    const [carsSelectLoading, setCarsSelectLoading] = useState(false);
    const [discountBy, setDiscountBy] = useState(null);
    const [form] = Form.useForm();

    useEffect(() => {
        const {
            locative_group,
            code,
            percent,
            expiration_date,
            description,
            cars,
            discountBy,
        } = rowData;

        let discountByCalculate = null;
        const carsLength = cars.length;

        if (locative_group && !carsLength) {
            discountByCalculate = 0;
        } else if (!locative_group && carsLength) {
            discountByCalculate = 1;
        } else if (locative_group && carsLength) {
            discountByCalculate = 2;
        }

        form.setFieldsValue({
            expiration_date: dayjs(dateTimeToString(expiration_date), {
                jalali: true,
            }),
            locative_group,
            code,
            description,
            percent,
            cars,
            discount_by: discountByCalculate,
        });

        onDiscountByChange(discountByCalculate);
    }, []);

    const getData = async (url, startCb, endCb) => {
        try {
            startCb();
            const { results } = await axios.get(url);
            endCb(results);
        } catch (error) {
            notify.danger(error);
        }
    };

    const onFinish = async (values) => {
        delete values.discount_by;
        values.expiration_date =
            values.expiration_date.format('YYYY-MM-DD HH:mm');

        setLoading(true);

        try {
            const data = await axios.patch(
                `discount/discount/${rowData.id}/`,
                values
            );

            setLoading(false);
            closeModal();
            refreshData();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    const onDiscountByChange = (value) => {
        setDiscountBy(value);

        if ((value === 0 || value === 2) && !locativeGroupList.length) {
            getData(
                'parking_spot/locative_group/',
                () => setlocativeGroupSelectLoading(true),
                (results) => {
                    setlocativeGroupSelectLoading(false);
                    setLocativeGroupList(results);
                }
            );
        }

        if ((value === 1 || value === 2) && !carsList.length) {
            getData(
                'car/car_plate',
                () => setCarsSelectLoading(true),
                (results) => {
                    setCarsSelectLoading(false);
                    // const carsWithStringPlateNumber = results.map((item) => {
                    //     const plate_number_string = numberToPlate(
                    //         item.plate_number
                    //     );

                    //     if (plate_number_string !== undefined) {
                    //         return {
                    //             ...item,
                    //             plate_number_string: plate_number_string,
                    //         };
                    //     }
                    // });

                    setCarsList(
                        // carsWithStringPlateNumber.filter(
                        //     (item) => item !== undefined
                        // )
                        carListWithStringPlateNumber(results)
                    );
                }
            );
        }
    };

    return (
        <Row align='center'>
            <Spin spinning={loading}>
                <Form
                    form={form}
                    labelCol={{ span: 10 }}
                    wrapperCol={{ span: 24 }}
                    onFinish={onFinish}
                    autoComplete='off'
                >
                    <Form.Item
                        name='discount_by'
                        label={t('discount_by')}
                        rules={[{ required: true }]}
                    >
                        <Select onChange={onDiscountByChange}>
                            <Option value={0} key={0}>
                                {t('locative_group_name')}
                            </Option>
                            <Option value={1} key={1}>
                                {t('plate_number')}
                            </Option>
                            <Option value={2} key={2}>
                                {t('both')}
                            </Option>
                        </Select>
                    </Form.Item>

                    {(discountBy === 0 || discountBy === 2) && (
                        <Form.Item
                            name='locative_group'
                            label={t('locative_group_name')}
                            rules={[{ required: true }]}
                        >
                            <Select loading={locativeGroupSelectLoading}>
                                {locativeGroupList.map((item) => {
                                    return (
                                        <Option value={item.id} key={item.id}>
                                            {item.title}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>
                    )}

                    {(discountBy === 1 || discountBy === 2) && (
                        <Form.Item
                            name='cars'
                            label={t('plate_number')}
                            rules={[{ required: true }]}
                        >
                            <Select
                                className='car-plate-select'
                                loading={carsSelectLoading}
                                mode='multiple'
                                // maxTagCount='responsive'
                                allowClear
                                filterOption={(e, o) => {
                                    return (
                                        o.children.toString().indexOf(e) >= 0
                                    );
                                }}
                            >
                                {carsList.map((item) => {
                                    return (
                                        <Option value={item.id} key={item.id}>
                                            {item.plate_number_string}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>
                    )}

                    <Form.Item
                        label={t('code')}
                        name='code'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                        normalize={(value) => getNumeric(value)}
                    >
                        <Input
                            placeholder={t('numeric_value')}
                            className='input-ltr'
                        />
                    </Form.Item>

                    <Form.Item
                        label={t('percent')}
                        name='percent'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                        normalize={(value) => getPercent(value)}
                    >
                        <Input
                            placeholder={t('numeric_value')}
                            className='input-ltr'
                        />
                    </Form.Item>

                    <Form.Item
                        label={t('discount_date')}
                        name='expiration_date'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                    >
                        <DatePickerJalali showTime format='YYYY-MM-DD HH:mm' />
                    </Form.Item>

                    <Form.Item label={t('description')} name='description'>
                        <TextArea />
                    </Form.Item>

                    <div className='modal-footer'>
                        <Form.Item>
                            <Button
                                type='primary'
                                htmlType='submit'
                                className='wide-button'
                            >
                                {t('edit')}
                            </Button>
                        </Form.Item>
                    </div>
                </Form>
            </Spin>
        </Row>
    );
};

export default DiscountNormalEdit;
