import { useState, useEffect } from 'react';
import t from 'helpers/translation';
import { Table, Card, Space, Modal, Popconfirm } from 'antd';
import { FormOutlined, DeleteOutlined } from '@ant-design/icons';
import axios from 'axios';
import notify from 'helpers/notify';
import { formatDate } from 'helpers/generalHelpers';
import { numberToPlate } from 'helpers/plate';
import DiscountNormalAdd from 'components/panels/admin/discount/normal/DiscountNormalAdd';
import DiscountNormalEdit from 'components/panels/admin/discount/normal/DiscountNormalEdit';
import useData from 'hooks/useData';
import useAdd from 'hooks/useAdd';

const DiscountNormalList = () => {
    const { data, loading, total, pageSize, onChange, getData, setData } =
        useData('discount/discount/');
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [modalComponent, setModalComponent] = useState(null);
    const [modalTitle, setModalTitle] = useState('');

    const columns = [
        {
            title: 'id',
            dataIndex: 'id',
        },
        {
            title: t('plate_number'),
            render: ({ cars_detail }) => {
                return cars_detail.length
                    ? cars_detail.map((item) => {
                          return (
                              <span key={item.plate_number}>
                                  {numberToPlate(item.plate_number)}
                              </span>
                          );
                      })
                    : '-';
            },
        },
        {
            title: t('locative_group_name'),
            render: ({ locative_group }) => locative_group || '-',
        },
        {
            title: t('percent'),
            dataIndex: 'percent',
        },
        {
            title: t('code'),
            dataIndex: 'code',
        },
        {
            title: t('expiration_date'),
            render: ({ expiration_date }) => formatDate(expiration_date),
        },
        {
            title: t('description'),
            render: ({ description }) => description || '-',
        },
        {
            title: t('actions'),
            render: (row) => {
                return (
                    <Space size='middle'>
                        <FormOutlined
                            className='icon-link icon-edit'
                            onClick={() => showModal('edit_discount', row)}
                        />
                        <Popconfirm
                            title={t('are_you_sure')}
                            onConfirm={() => remove(row.id)}
                        >
                            <DeleteOutlined className='icon-link icon-danger' />
                        </Popconfirm>
                    </Space>
                );
            },
        },
    ];

    const closeModal = () => {
        setIsModalVisible(false);
    };

    const showModal = (title, rowData = null) => {
        setIsModalVisible(true);
        setModalTitle(title);

        if (title === 'add_discount') {
            setModalComponent(
                <DiscountNormalAdd refreshData={getData} closeModal={closeModal} />
            );
        } else if (title === 'edit_discount') {
            setModalComponent(
                <DiscountNormalEdit
                    rowData={rowData}
                    refreshData={getData}
                    closeModal={closeModal}
                />
            );
        }

        return false;
    };

    const remove = async (id) => {
        try {
            await axios.delete(`discount/discount/${id}/`);

            // remove from data
            const updatedData = data.filter((item) => item.id !== id);
            setData(updatedData);
        } catch (error) {
            notify.danger(error);
        }
    };

    return (
        <div className='fill-page'>
            <Card
                title={t('discount_normal')}
                extra={useAdd(() => showModal('add_discount'))}
            >
                <Table
                    loading={loading}
                    dataSource={data}
                    columns={columns}
                    rowKey={(record) => record.id}
                    scroll={{ x: true }}
                    pagination={{
                        total,
                        pageSize,
                        hideOnSinglePage: true,
                        onChange,
                    }}
                />
            </Card>
            <Modal
                title={t(modalTitle)}
                visible={isModalVisible}
                footer={null}
                destroyOnClose={true}
                width={550}
                onCancel={closeModal}
            >
                {modalComponent}
            </Modal>
        </div>
    );
};

export default DiscountNormalList;
