import { useState, useEffect } from 'react';
import { Row, Spin, Form, Input, Select, Button } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import {
    getNumericFormatted,
    getNumeric,
    getPercent,
    formatNumber,
    unformat,
} from 'helpers/generalHelpers';

const { Option } = Select;
const { TextArea } = Input;

const DiscountBusinessAdd = ({ refreshData, closeModal }) => {
    const [loading, setLoading] = useState(false);

    const onFinish = async (values) => {
        console.log(values);

        // setLoading(true);

        // try {
        //     const data = await axios.post('discount/business/', values);

        //     setLoading(false);
        //     closeModal();
        //     refreshData();
        // } catch (error) {
        //     notify.danger(error);
        // }

        // setLoading(false);
    };

    return (
        <Row align='center'>
            <Spin spinning={loading}>
                <Form
                    labelCol={{ span: 10 }}
                    wrapperCol={{ span: 24 }}
                    onFinish={onFinish}
                    autoComplete='off'
                >
                    <Form.Item
                        name='type'
                        label={t('type')}
                        rules={[{ required: true }]}
                    >
                        <Select>
                            <Option value={1} key={1}>
                                1
                            </Option>
                            <Option value={2} key={2}>
                                2
                            </Option>
                        </Select>
                    </Form.Item>

                    <Form.Item
                        name='disscount_mode'
                        label={t('discount_mode')}
                        rules={[{ required: true }]}
                    >
                        <Select>
                            <Option value={0} key={0}>
                                0
                            </Option>
                            <Option value={1} key={1}>
                                1
                            </Option>
                            <Option value={2} key={2}>
                                2
                            </Option>
                        </Select>
                    </Form.Item>

                    <Form.Item
                        label={t('bussiness_code')}
                        name='bussiness_code'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                        normalize={(value) => getNumeric(value)}
                    >
                        <Input
                            placeholder={t('numeric_value')}
                            className='input-ltr'
                        />
                    </Form.Item>

                    <Form.Item
                        label={t('discount_value')}
                        name='disscount_value'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                        normalize={(value) => formatNumber(value)}
                    >
                        <Input
                            placeholder={t('numeric_value')}
                            className='input-ltr'
                        />
                    </Form.Item>

                    <Form.Item label={t('description')} name='description'>
                        <TextArea />
                    </Form.Item>

                    <div className='modal-footer'>
                        <Form.Item>
                            <Button
                                type='primary'
                                htmlType='submit'
                                className='wide-button'
                            >
                                {t('add')}
                            </Button>
                        </Form.Item>
                    </div>
                </Form>
            </Spin>
        </Row>
    );
};

export default DiscountBusinessAdd;
