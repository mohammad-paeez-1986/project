import { useState, useEffect } from 'react';
import { Row, Spin, Form, Input, Select, Switch, Button } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';

const { Option } = Select;
const { TextArea } = Input;

const LocativeGroupEdit = ({ refreshData, closeModal, rowData }) => {
    const [loading, setLoading] = useState(false);

    const [adsGroupList, setAdsGroupList] = useState([]);
    const [parkingSpotList, setParkingSpotList] = useState([]);
    const [selectLoading, setSelectLoading] = useState(true);
    const [form] = Form.useForm();

    useEffect(() => {
        const {
            title,
            car_dispencer_show_name,
            description,
            parking_spot,
            ads_group,
            is_show_in_car_dispencer,
        } = rowData;

        form.setFieldsValue({
            title,
            car_dispencer_show_name,
            description,
            parking_spot,
            is_show_in_car_dispencer,
            ads_group,
        });
    }, []);

    useEffect(async () => {
        try {
            const res = await axios.all([
                axios.get('parking_spot/ads_group/'),
                axios.get('parking_spot/parking_spot/'),
            ]);

            setSelectLoading(false);
            setAdsGroupList(res[0].results);
            setParkingSpotList(res[1].results);
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    const onFinish = async (values) => {
        // console.log(values);
        // return;
        setLoading(true);

        try {
            const data = await axios.patch(
                `parking_spot/locative_group/${rowData.id}/`,
                values
            );

            setLoading(false);
            closeModal();
            refreshData();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <Row align='center'>
            <Spin spinning={loading}>
                <Form
                    labelCol={{ span: 7 }}
                    wrapperCol={{ span: 24 }}
                    onFinish={onFinish}
                    autoComplete='off'
                    form={form}
                >
                    <Form.Item
                        label={t('title')}
                        name='title'
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label={t('car_dispencer_show_name')}
                        name='car_dispencer_show_name'
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        name='ads_group'
                        label={t('ads_group')}
                        rules={[{ required: true }]}
                    >
                        <Select
                            loading={selectLoading}
                            mode='multiple'
                            className='multiple-select'
                        >
                            {adsGroupList.map((item) => {
                                return (
                                    <Option value={item.id} key={item.id}>
                                        {item.title}
                                    </Option>
                                );
                            })}
                        </Select>
                    </Form.Item>

                    <Form.Item
                        name='parking_spot'
                        label={t('parking_spots')}
                        rules={[{ required: true }]}
                    >
                        <Select
                            loading={selectLoading}
                            mode='multiple'
                            className='multiple-select'
                            allowClear
                            showSearch={true}
                            filterOption={(e, o) => {
                                return (
                                    o.children
                                        .toString()
                                        .indexOf(e.toLowerCase()) >= 0
                                );
                            }}
                        >
                            {parkingSpotList.map((item) => {
                                return (
                                    <Option value={item.id} key={item.id}>
                                        {item.properties_name}
                                    </Option>
                                );
                            })}
                        </Select>
                    </Form.Item>

                    <Form.Item
                        name='is_show_in_car_dispencer'
                        label={t('is_show_in_car_dispencer')}
                        valuePropName='checked'
                    >
                        <Switch
                        // defaultChecked={rowData.is_show_in_car_dispencer}
                        />
                    </Form.Item>

                    <Form.Item label={t('description')} name='description'>
                        <TextArea />
                    </Form.Item>

                    <div className='modal-footer'>
                        <Form.Item>
                            <Button
                                type='primary'
                                htmlType='submit'
                                className='wide-button'
                            >
                                {t('edit')}
                            </Button>
                        </Form.Item>
                    </div>
                </Form>
            </Spin>
        </Row>
    );
};

export default LocativeGroupEdit;
