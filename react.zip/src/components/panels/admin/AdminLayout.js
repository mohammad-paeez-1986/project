import React, { useState } from 'react';
import { Layout } from 'antd';
import AdminHeader from 'components/panels/admin/AdminHeader';
import AdminSider from 'components/panels/admin/AdminSider';
import AdminFooter from 'components/panels/admin/AdminFooter';

const { Content } = Layout;

const AdminLayout = ({ children }) => {
    const [collapsed, setCollapsed] = useState(false);

    console.log('admin-layout');

    return (
        <>
            <Layout>
                <AdminSider collapsed={collapsed} toggle={setCollapsed} />
                <Layout>
                    <AdminHeader collapsed={collapsed} toggle={setCollapsed} />
                    <Content className='content'>{children}</Content>
                    <AdminFooter />
                </Layout>
            </Layout>
        </>
    );
};

export default React.memo(AdminLayout);
