import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Layout, Menu } from 'antd';
import { menuKey, subMenuKey } from 'helpers/defualtMenuKeys';
import t from 'helpers/translation';
import {
    TeamOutlined,
    VerticalAlignMiddleOutlined,
    DollarOutlined,
    PercentageOutlined,
    FileTextOutlined,
    MessageOutlined,
    FileSearchOutlined,
    PieChartOutlined,
    MenuUnfoldOutlined,
    MenuFoldOutlined,
    MailOutlined,
} from '@ant-design/icons';

const { Sider } = Layout;
const { SubMenu } = Menu;

const AdminSider = ({ collapsed, toggle }) => {
    console.log('sider');
    return (
        <Sider
            collapsed={true}
            trigger='click'
            breakpoint='lg'
            collapsedWidth='80'
            // onBreakpoint={(broken) => {
            //     if (broken) {
            //         toggle(true);
            //     } else {
            //         toggle(false);
            //     }
            // }}
            className='sider'
        >
            {/* <div className='logo'>ADMIN</div> */}
            <div className='menu-container'>
                <Menu
                    defaultSelectedKeys={[menuKey]}
                    defaultOpenKeys={[subMenuKey]}
                    mode='inline'
                    theme='dark'
                >
                    <Menu.Item key='operators' icon={<TeamOutlined />}>
                        <Link to='operators'>{t('operator')}</Link>
                    </Menu.Item>
                    <Menu.Item
                        key='locative-groups'
                        icon={<VerticalAlignMiddleOutlined />}
                    >
                        <Link to='locative-groups'>{t('locative_group')}</Link>
                    </Menu.Item>
                    <Menu.Item key='statistics' icon={<PieChartOutlined />}>
                        <Link to='statistics'>{t('statistics')}</Link>
                    </Menu.Item>
                    <Menu.Item key='tariffs' icon={<DollarOutlined />}>
                        <Link to='tariffs'>{t('tariff')}</Link>
                    </Menu.Item>
                    <Menu.Item key='discounts' icon={<PercentageOutlined />}>
                        <Link to='discounts'>{t('discount')}</Link>
                    </Menu.Item>
                    <Menu.Item key='config-files' icon={<FileTextOutlined />}>
                        <Link to='config-files'>{t('config_file')}</Link>
                    </Menu.Item>
                    <Menu.Item key='messages' icon={<MessageOutlined />}>
                        <Link to='messages'>{t('messages')}</Link>
                    </Menu.Item>
                    <Menu.Item key='plate-search' icon={<FileSearchOutlined />}>
                        <Link to='plate-search'>{t('plate_search')}</Link>
                    </Menu.Item>
                </Menu>
            </div>
        </Sider>
    );
};

export default React.memo(AdminSider);
