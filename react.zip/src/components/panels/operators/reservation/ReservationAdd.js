import { useState, useEffect } from 'react';
import { Row, Col, Spin, Form, Input, Select, Button } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import {
    getNumericFormatted,
    getNumeric,
    formatNumber,
} from 'helpers/generalHelpers';
import {
    DatePicker as DatePickerJalali,
    useJalaliLocaleListener,
} from 'antd-jalali';

const { Option } = Select;

const ReservationAdd = ({ refreshData, closeModal }) => {
    useJalaliLocaleListener();
    const [loading, setLoading] = useState(false);
    const [locativeGroupList, setLocativeGroupList] = useState([]);
    const [plateNumberList, setPlateNumberList] = useState([]);
    const [parkingSpotList, setParkingSpotList] = useState([]);
    const [reserveBy, setReserveBy] = useState(null);
    // recognize which api is loaded before, prevent to load it again(to get above lists)
    const [loadFlags, setloadFlags] = useState({
        locativeGroup: false,
        plateNumber: false,
        parkingSpot: false,
    });
    // select loading states
    const [selectLoading, setSelectLoading] = useState({
        locativeGroup: false,
        plateNumber: false,
        parkingSpot: false,
    });

    // const [selectLoading, setSelectLoading] = useState(true);

    // useEffect(async () => {
    //     try {
    //         const res = await axios.all([
    //             axios.get('parking_spot/locative_group/'),
    //             axios.get('car/car_plate/'),
    //         ]);
    //         setSelectLoading(false);
    //         setLocativeGroupList(res[0].results);
    //         setCarList(res[1].results);
    //     } catch (error) {
    //         notify.danger(error);
    //     }
    // }, []);

    const fillList = (name, data) => {
        console.log(data)
        switch (name) {
            case 'locativeGroup':
                setLocativeGroupList(data);
                break;
            case 'plateNumber':
                setPlateNumberList(data);
                break;
            case 'parkingSpot':
                setParkingSpotList(data);
                break;
            default:
                return false;
        }
    };

    const getData = async (url, name) => {
        setSelectLoading((prev) => {
            return {
                ...prev,
                [name]: true,
            };
        });
        try {
            const { results } = await axios.get(url);

            setloadFlags((prev) => {
                return { ...prev, [name]: true };
            });

            fillList(name, results);
        } catch (error) {
            notify.danger(error);
        }

        setSelectLoading((prev) => {
            return {
                ...prev,
                [name]: false,
            };
        });
    };

    const onFinish = async (values) => {
        console.log(values)
        return
        setLoading(true);

        try {
            const data = await axios.post(
                'parking_spot/reserve_record/',
                values
            );

            setLoading(false);
            closeModal();
            refreshData();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    const onReserveByChange = (value) => {
        setReserveBy(value);

        switch (value) {
            case 1:
                !loadFlags.locativeGroup &&
                    getData('parking_spot/locative_group/', 'locativeGroup');
                break;
            case 2:
                !loadFlags.plateNumber &&
                    getData('car/car_plate/', 'plateNumber');
                !loadFlags.locativeGroup &&
                    getData('parking_spot/locative_group/', 'locativeGroup');
                break;
            case 3:
                !loadFlags.plateNumber &&
                    getData('car/car_plate/', 'plateNumber');
                !loadFlags.parkingSpot &&
                    getData('parking_spot/parking_spot/', 'parkingSpot');
                break;
            default:
                return false;
        }
    };

    return (
        <Row align='center'>
            <Col span={16}>
                <Spin spinning={loading}>
                    <Form
                        labelCol={{ span: 8 }}
                        wrapperCol={{ span: 24 }}
                        onFinish={onFinish}
                        autoComplete='off'
                    >
                        <Form.Item
                            label={t('reserve_type')}
                            name='reserve_type'
                            rules={[
                                {
                                    required: true,
                                },
                            ]}
                        >
                            <Select>
                                <Option value='hourly' key='hourly'>
                                    {t('hourly')}
                                </Option>
                                <Option value='daily' key='daily'>
                                    {t('daily')}
                                </Option>
                            </Select>
                        </Form.Item>

                        <Form.Item
                            label={t('start_from')}
                            name='start_from'
                            rules={[
                                {
                                    required: true,
                                },
                            ]}
                        >
                            <DatePickerJalali
                                format='YYYY-MM-DD'
                                style={{width:'100%'}}
                            />
                        </Form.Item>

                        <Form.Item
                            name='reserve_by'
                            label={t('reserve_by')}
                            rules={[{ required: true }]}
                        >
                            <Select onChange={onReserveByChange}>
                                <Option value={1} key={1}>
                                    {`${t('reserve_code')} + ${t(
                                        'locative_group_name'
                                    )}`}
                                </Option>
                                <Option value={2} key={2}>
                                    {`${t('locative_group_name')} + ${t(
                                        'plate_number'
                                    )}`}
                                </Option>
                                <Option value={3} key={3}>
                                    {`${t('plate_number')} + ${t(
                                        'parking_spots'
                                    )}`}
                                </Option>
                            </Select>
                        </Form.Item>

                        {reserveBy === 1 && (
                            <Form.Item
                                label={t('reserve_code')}
                                name='reserve_code'
                                rules={[
                                    {
                                        required: true,
                                    },
                                ]}
                                normalize={(value) => getNumeric(value)}
                            >
                                <Input placeholder={t('numeric_value')} />
                            </Form.Item>
                        )}

                        {/* optionally loaded */}

                        {(reserveBy === 1 || reserveBy === 2) && (
                            <Form.Item
                                name='locative_group'
                                label={t('locative_group_name')}
                                rules={[{ required: true }]}
                            >
                                <Select loading={selectLoading.locativeGroup}>
                                    {locativeGroupList.map((item) => {
                                        return (
                                            <Option
                                                value={item.id}
                                                key={item.id}
                                            >
                                                {item.title}
                                            </Option>
                                        );
                                    })}
                                </Select>
                            </Form.Item>
                        )}

                        {(reserveBy === 2 || reserveBy === 3) && (
                            <Form.Item
                                name='car_plates'
                                label={t('plate_number')}
                                rules={[{ required: true }]}
                                multiple
                            >
                                <Select
                                    loading={selectLoading.plateNumber}
                                    mode='multiple'
                                    maxTagCount='responsive'
                                    allowClear
                                    filterOption={(e, o) => {
                                        return (
                                            o.children.toString().indexOf(e) >=
                                            0
                                        );
                                    }}
                                >
                                    {plateNumberList.map((item) => {
                                        return (
                                            <Option
                                                value={item.id}
                                                key={item.id}
                                            >
                                                {item.plate_number}
                                            </Option>
                                        );
                                    })}
                                </Select>
                            </Form.Item>
                        )}

                        {reserveBy === 3 && (
                            <Form.Item
                                name='parking_spots'
                                label={t('parking_spots')}
                                rules={[{ required: true }]}
                                multiple
                            >
                                <Select
                                    loading={selectLoading.parkingSpot}
                                    mode='multiple'
                                    maxTagCount='responsive'
                                    allowClear
                                    filterOption={(e, o) => {
                                        return (
                                            o.children.toString().indexOf(e) >=
                                            0
                                        );
                                    }}
                                >
                                    {parkingSpotList.map((item) => {
                                        return (
                                            <Option
                                                value={item.id}
                                                key={item.id}
                                            >
                                                {item.properties_name}
                                            </Option>
                                        );
                                    })}
                                </Select>
                            </Form.Item>
                        )}

                        <div className='modal-footer'>
                            <Form.Item>
                                <Button
                                    type='primary'
                                    htmlType='submit'
                                    className='wide-button'
                                >
                                    {t('add')}
                                </Button>
                            </Form.Item>
                        </div>
                    </Form>
                </Spin>
            </Col>
        </Row>
    );
};

export default ReservationAdd;
