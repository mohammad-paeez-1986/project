import React, { useState, useEffect } from 'react';
import t from 'helpers/translation';
import { Table, Card, Space, Popconfirm, Modal } from 'antd';
import axios from 'axios';
import {
    FormOutlined,
    DeleteOutlined,
} from '@ant-design/icons';
import notify from 'helpers/notify';
import ReservationAdd from 'components/panels/operators/reservation/ReservationAdd';
import ReservationEdit from 'components/panels/operators/reservation/ReservationEdit';
import { formatNumber } from 'helpers/generalHelpers';
import useData from 'hooks/useData';
import useAdd from 'hooks/useAdd';

const ReservationList = () => {
    const { data, loading, total, pageSize, onChange, getData, setData } =
        useData('parking_spot/fee/');
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [modalComponent, setModalComponent] = useState(null);
    const [modalTitle, setModalTitle] = useState('');

    const columns = [
        {
            title: t('title'),
            dataIndex: 'title',
        },
        {
            title: t('locative_group_name'),
            dataIndex: 'locative_group_name',
        },
        {
            title: t('entrance_price'),
            render: ({ entrance_price }) => formatNumber(entrance_price),
        },
        {
            title: t('hourly_price'),
            render: ({ hourly_price }) => formatNumber(hourly_price),
        },
        {
            title: t('actions'),
            render: (row) => {
                return (
                    <Space size='middle'>
                        <FormOutlined
                            className='icon-link icon-edit'
                            onClick={() => showModal('edit_reserve', row)}
                        />
                        <Popconfirm
                            title={t('are_you_sure')}
                            onConfirm={() => remove(row.id)}
                        >
                            <DeleteOutlined className='icon-link icon-danger' />
                        </Popconfirm>
                    </Space>
                );
            },
        },
    ];

    const closeModal = () => {
        setIsModalVisible(false);
    };

    const showModal = (title, rowData = null) => {
        setIsModalVisible(true);
        setModalTitle(title);

        if (title === 'add_reserve') {
            setModalComponent(
                <ReservationAdd refreshData={getData} closeModal={closeModal} />
            );
        } else if (title === 'edit_reserve') {
            setModalComponent(
                <ReservationEdit
                    rowData={rowData}
                    refreshData={getData}
                    closeModal={closeModal}
                />
            );
        }

        return false;
    };

    const remove = async (id) => {
        try {
            await axios.delete(`parking_spot/fee/${id}/`);

            // remove from data
            const updatedData = data.filter((item) => item.id !== id);
            setData(updatedData);
        } catch (error) {
            notify.danger(error);
        }
    };

    return (
        <div className='fill-page'>
            <Card
                title={t('reservation')}
                extra={
                    useAdd(() => showModal('add_reserve'))
                }
            >
                <Table
                    loading={loading}
                    dataSource={data}
                    columns={columns}
                    rowKey={(record) => record.id}
                    scroll={{ x: true }}
                    pagination={{
                        total,
                        pageSize,
                        hideOnSinglePage: true,
                        onChange,
                    }}
                />
            </Card>
            <Modal
                title={t(modalTitle)}
                visible={isModalVisible}
                footer={null}
                destroyOnClose={true}
                width={550}
                onCancel={closeModal}
            >
                {modalComponent}
            </Modal>
        </div>
    );
};

export default ReservationList;
