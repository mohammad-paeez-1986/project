import { useState, useEffect } from 'react';
import { Row, Col, Spin, Form, Input, Select, Button } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import {
    getNumericFormatted,
    getNumeric,
    formatNumber,
} from 'helpers/generalHelpers';
import {
    DatePicker as DatePickerJalali,
    useJalaliLocaleListener,
} from 'antd-jalali';

const { Option } = Select;

const ReservationEdit = ({ refreshData, closeModal }) => {
    useJalaliLocaleListener();
    const [loading, setLoading] = useState(false);
    const [locativeGroupList, setLocativeGroupList] = useState([]);
    const [carList, setCarList] = useState([]);
    const [selectLoading, setSelectLoading] = useState(true);

    useEffect(async () => {
        try {
            const res = await axios.all([
                axios.get('parking_spot/locative_group/'),
                axios.get('car/car_plate/'),
            ]);
            setSelectLoading(false);
            setLocativeGroupList(res[0].results);
            setCarList(res[1].results);
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    const onFinish = async (values) => {
        setLoading(true);

        try {
            const data = await axios.post(
                'parking_spot/reserve_record/',
                values
            );

            setLoading(false);
            closeModal();
            refreshData();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <Row align='center'>
            <Col span={16}>
                <Spin spinning={loading}>
                    <Form
                        labelCol={{ span: 8 }}
                        wrapperCol={{ span: 24 }}
                        onFinish={onFinish}
                        autoComplete='off'
                    >
                        <Form.Item
                            label={t('reserve_type')}
                            name='reserve_type'
                            rules={[
                                {
                                    required: true,
                                },
                            ]}
                        >
                            <Select>
                                <Option value='hourly' key='hourly'>
                                    {t('hourly')}
                                </Option>
                                <Option value='daily' key='daily'>
                                    {t('daily')}
                                </Option>
                            </Select>
                        </Form.Item>

                        <Form.Item
                            label={t('start_from')}
                            name='start_from'
                            rules={[
                                {
                                    required: true,
                                },
                            ]}
                        >
                            <DatePickerJalali
                                showTime
                                format='YYYY-MM-DD HH:mm'
                            />
                        </Form.Item>

                        <Form.Item
                            label={t('reserve_code')}
                            name='reserve_code'
                            rules={[
                                {
                                    required: true,
                                },
                            ]}
                            normalize={(value) => getNumeric(value)}
                        >
                            <Input placeholder={t('numeric_value')} />
                        </Form.Item>

                        <Form.Item
                            name='locative_group'
                            label={t('locative_group_name')}
                            rules={[{ required: true }]}
                        >
                            <Select loading={selectLoading}>
                                {locativeGroupList.map((item) => {
                                    return (
                                        <Option value={item.id} key={item.id}>
                                            {item.title}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>

                        <Form.Item
                            name='car_plates'
                            label={t('plate_number')}
                            rules={[{ required: true }]}
                            multiple
                        >
                            <Select
                                loading={selectLoading}
                                mode='multiple'
                                maxTagCount='responsive'
                                allowClear
                                filterOption={(e, o) => {
                                    return (
                                        o.children.toString().indexOf(e) >= 0
                                    );
                                }}
                            >
                                {carList.map((item) => {
                                    return (
                                        <Option value={item.id} key={item.id}>
                                            {item.plate_number}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>

                        <div className='modal-footer'>
                            <Form.Item>
                                <Button
                                    type='primary'
                                    htmlType='submit'
                                    className='wide-button'
                                >
                                    {t('add')}
                                </Button>
                            </Form.Item>
                        </div>
                    </Form>
                </Spin>
            </Col>
        </Row>
    );
};

export default ReservationEdit;
