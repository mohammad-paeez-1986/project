import React from 'react';
import t from 'helpers/translation';
import { Form, Input, Button, Space } from 'antd';
import { createFilterArray } from 'helpers/generalHelpers';

const EntranceExitFilter = ({ createFilterQs }) => {
    const [filterForm] = Form.useForm();

    const onFinish = (values) => {
        createFilterQs(createFilterArray(values));
    };

    const onReset = () => { 
        // console.log('ss')
        createFilterQs(createFilterArray([]));
     }

    return (
        <div style={{ padding: 10 }}>
            <Form
                labelCol={{ span: 7 }}
                // wrapperCol={{ span: 24 }}
                onFinish={onFinish}
                autoComplete='off'
                form={filterForm}
            >
                <Form.Item label={t('username')} name='username'>
                    <Input className='input-ltr' />
                </Form.Item>

                <Form.Item label={t('password')} name='password'>
                    <Input className='input-ltr' />
                </Form.Item>

                <div className='modal-footer'>
                    <Form.Item>
                        <Space size='large'>
                            <Button type='primary' ghost htmlType='submit'>
                                {t('add_filter')}
                            </Button>

                            <Button
                                onClick={onReset}
                                type='danger'
                                dashed
                                ghost
                                htmlType='reset'
                            >
                                X
                            </Button>
                        </Space>
                    </Form.Item>
                </div>
            </Form>
        </div>
    );
};

export default EntranceExitFilter;
