import React, { useState, useEffect } from 'react';
import t from 'helpers/translation';
import { Table, Card, Space, Modal, Image } from 'antd';
import {
    FormOutlined,
    DeleteOutlined,
    FileImageOutlined,
} from '@ant-design/icons';
import axios from 'axios';
import notify from 'helpers/notify';
import useData from 'hooks/useData';
import useAdd from 'hooks/useAdd';
import useFilter from 'hooks/useFilter';
import { formatNumber, formatDate } from 'helpers/generalHelpers';
import { numberToPlate } from 'helpers/plate';
import EntranceExitFilter from 'components/panels/operators/entrance-exit/EntranceExitFilter';

const EntranceExitList = () => {
    const {
        data,
        loading,
        total,
        pageSize,
        onChange,
        getData,
        setData,
        createFilterQs,
        filterArray,
    } = useData('ticket/ticket/');

    const [isModalVisible, setIsModalVisible] = useState(false);
    const [modalComponent, setModalComponent] = useState(null);
    const [modalTitle, setModalTitle] = useState('');

    const columns = [
        {
            title: t('plate_number'),
            render: ({ car_detail }) => {
                return (
                    <Space align='baseline'>
                        <span key={car_detail.plate_number}>
                            {numberToPlate(car_detail.plate_number)}
                        </span>{' '}
                        <Image
                            placeholder={
                                <FileImageOutlined className='icon-link icon-edit float-left' />
                            }
                            preview={{
                                src: car_detail.get_last_pic,
                            }}
                        />
                    </Space>
                );
            },
        },
        {
            title: t('corridor_name'),
            render: ({ corridor_name }) => corridor_name || '-',
        },

        {
            title: t('locative_group_name'),
            render: ({ locative_group_name }) => locative_group_name || '-',
        },
        {
            title: t('enter_time'),
            render: ({ enter_time }) => formatDate(enter_time),
        },
        {
            title: t('exit_time'),
            render: ({ exit_time }) =>
                !exit_time ? '-' : formatDate(exit_time),
        },
        {
            title: t('estimate_price'),
            render: ({ estimate_price }) =>
                estimate_price ? formatNumber(estimate_price) : '-',
        },
        // {
        //     title: t('actions'),
        //     render: (row) => {
        //         return (
        //             <Space size='middle'>
        //                 <FormOutlined
        //                     className='icon-link icon-edit'
        //                     onClick={() => showModal('edit_operator', row)}
        //                 />
        //                 {/* <Popconfirm
        //                     title={t('are_you_sure')}
        //                     onConfirm={() => remove(row.id)}
        //                 >
        //                     <DeleteOutlined className='icon-link icon-danger' />
        //                 </Popconfirm> */}
        //             </Space>
        //         );
        //     },
        // },
    ];

    const closeModal = () => {
        setIsModalVisible(false);
    };

    const showModal = (title, rowData = null) => {
        setIsModalVisible(true);
        setModalTitle(title);

        if (title === 'add_operator') {
            // setModalComponent(
            //     <OperatorAdd refreshData={getData} closeModal={closeModal} />
            // );
        } else if (title === 'edit_operator') {
            setModalComponent();
            // <OperatorEdit
            //     rowData={rowData}
            //     refreshData={getData}
            //     closeModal={closeModal}
            // />
        }

        return false;
    };

    const remove = async (id) => {
        try {
            await axios.delete(`users/${id}/`);

            // remove from data
            const updatedData = data.filter((item) => item.id !== id);
            setData(updatedData);
        } catch (error) {
            notify.danger(error);
        }
    };

    return (
        <>
            <Card
                title={t('entrance_exit')}
                extra={[
                    useFilter(
                        <EntranceExitFilter createFilterQs={createFilterQs} />,
                        filterArray
                    ),
                    // useAdd(() => showModal('add_operator')),
                    // <button onClick={}>click</button>,
                ]}
            >
                <Table
                    loading={loading}
                    dataSource={data}
                    columns={columns}
                    rowKey={(record) => record.id}
                    scroll={{ x: true }}
                    pagination={{
                        total,
                        pageSize: 10,
                        hideOnSinglePage: true,
                        onChange,
                    }}
                />
            </Card>
            <Modal
                title={t(modalTitle)}
                visible={isModalVisible}
                footer={null}
                destroyOnClose={true}
                width={550}
                onCancel={closeModal}
            >
                {modalComponent}
            </Modal>
        </>
    );
};

export default EntranceExitList;
