import React from 'react';
import { Layout } from 'antd';
import {
    MessageOutlined,
    PercentageOutlined,
    DiffOutlined,
    GiftOutlined,
    RetweetOutlined,
    EnvironmentOutlined,
    ContactsOutlined,
    CarryOutOutlined
} from '@ant-design/icons';
import { NavLink } from 'react-router-dom';

const { Header, Footer, Content } = Layout;
const OperatorDock = () => {
    console.log('dock');
    return (
        <Layout>
            <div className='opr-dock'>
                <ul>
                    <li>
                        <NavLink
                            to='maps'
                            className={({ isActive }) =>
                                isActive ? 'active' : undefined
                            }
                        >
                            <EnvironmentOutlined />
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to='entrance-exits'
                            className={({ isActive }) =>
                                isActive ? 'active' : undefined
                            }
                        >
                            <RetweetOutlined />
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to='reservations'
                            className={({ isActive }) =>
                                isActive ? 'active' : undefined
                            }
                        >
                            <CarryOutOutlined />
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to='discounts'
                            className={({ isActive }) =>
                                isActive ? 'active' : undefined
                            }
                        >
                            <PercentageOutlined />
                        </NavLink>
                    </li>

                    <li>
                        <NavLink
                            to='considerations'
                            className={({ isActive }) =>
                                isActive ? 'active' : undefined
                            }
                        >
                            <DiffOutlined />
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to='messages'
                            className={({ isActive }) =>
                                isActive ? 'active' : undefined
                            }
                        >
                            <MessageOutlined />
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to='profiles'
                            className={({ isActive }) =>
                                isActive ? 'active' : undefined
                            }
                        >
                            <ContactsOutlined />
                        </NavLink>
                    </li>
                </ul>
            </div>
        </Layout>
    );
};

export default React.memo(OperatorDock);
