import React from 'react';
import { useEffect } from 'react';
import { useCookies } from 'react-cookie';
import { Outlet, useNavigate } from 'react-router-dom';
import OperatorDock from 'components/panels/operators/layout/OperatorDock';
import OperatorHeader from 'components/panels/operators/layout/OperatorHeader';

const OperatorBase = () => {
    console.log('base');
    const [cookies, , removeCookie] = useCookies();
    const navigate = useNavigate();

    // scroll to top
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;

    useEffect(() => {
        const token = cookies['token'];
        const type = cookies['type'];

        if (!token) {
            navigate('/login');
        }

        if (!type) {
            removeCookie('token');
            navigate('/login');
        }

        if (type !== 'operator') {
            removeCookie('token');
            removeCookie('type');
            navigate('/login');
        }
    }, []);

    return (
        <>
            <OperatorHeader />
            <div className='fill-page bb'>
                <div className='opr-content'>
                    <Outlet />
                </div>
            </div>
            <OperatorDock />
        </>
    );
};

export default React.memo(OperatorBase);
