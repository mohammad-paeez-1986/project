import React, { useState, useEffect } from 'react';
import { Menu, Badge, Dropdown, List, Space } from 'antd';
import { MailOutlined, LogoutOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import t from 'helpers/translation';
import { useCookies } from 'react-cookie';
import MessageMenu from 'components/common/MessageMenu';

const OperatorHeader = ({ collapsed, toggle }) => {
    const [notificationList, setNotificationList] = useState([]);
    const [, , removeCookie] = useCookies([]);
    const navigate = useNavigate();

    useEffect(() => {
        console.log('socket');
        var socket = new WebSocket(
            'ws://194.5.175.154:8000/fa/ws/notifications/'
        );
        socket.addEventListener('open', () => {
            console.log('open');
        });
        socket.addEventListener('message', (e) => {
            setNotificationList((prev) => [...prev, e.data]);
            console.log(e.data);
        });

        // return () => WebSocket.close();
    }, []);

    const logout = () => {
        console.log('logout');
        removeCookie('token', { path: '/' });
        removeCookie('type', { path: '/' });

        navigate('/login', { replace: true });
    };

    return (
        <div className='header'>
            <div className='header-icons'>
                <Space size='large'>
                    <LogoutOutlined
                        className='logout-icon icon-link'
                        onClick={logout}
                    />
                    <MessageMenu />
                </Space>
            </div>
            <div className='header-title-opr'>{t('operator-panel')}</div>
        </div>
    );
};

export default React.memo(OperatorHeader);
