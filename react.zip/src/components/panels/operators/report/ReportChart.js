import { useState, useEffect, useRef } from 'react';
import { Chart as ChartJs } from 'chart.js/auto';
import { Bar, getDatasetAtEvent, getElementAtEvent } from 'react-chartjs-2';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import { formatDate } from 'helpers/generalHelpers';

const ReportChart = ({ object, doHighLight }) => {
    const [loading, setLoading] = useState(true);
    const [xAxisList, setXAxisList] = useState([]);
    const [labelList, setLabelList] = useState([]);
    const [datasets, setDatasets] = useState([]);
    const [data, setData] = useState([]);

    const chartRef = useRef();

    const onClick = (event) => {
        const element = getElementAtEvent(chartRef.current, event)[0];

        // get parking spots
        doHighLight([]);
        doHighLight(
            data[element.datasetIndex]?.chart_points[element.index]
                ?.parking_spot_ids
        );
        // console.log(
        //     data[element.datasetIndex]?.chart_points[element.index]
        //         ?.parking_spot_ids
        // );
    };

    useEffect(async () => {
        setLoading(true);

        try {
            const data = await axios.get(
                `reports/comparitive_report/?profile_id=${object.id}`
            );

            setData(data);
            //
            const firstChartData = data[0]?.chart_points;

            setXAxisList(
                firstChartData.map((item) => item.date_time.substr(0, 10))
            );

            // preaper labesl
            let labelArray = [];
            data.map(({ value }) => {
                labelArray.push(value);
            });

            setLabelList(labelArray);

            // create and fill datasets
            let datasetsArray = [];

            datasetsArray.push({
                id: 1,
                label: labelList[0],
                data: firstChartData.map((item) => item.value),
                backgroundColor: '#486',
            });

            console.log(firstChartData.map((item) => item.value));

            // preaper second line
            if (data.length > 1) {
                const secondChartData = data[1]?.chart_points;

                datasetsArray.push({
                    id: 2,
                    label: labelList[1],
                    data: secondChartData.map((item) => item.value),
                    backgroundColor: '#f98',
                });
            }

            setDatasets(datasetsArray);
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    }, [object]);

    return (
        <div className='sss'>
            <Bar
                ref={chartRef}
                data={{
                    labels: xAxisList,
                    options: {
                        responsive: true,
                        events: ['click'],
                    },
                    datasets,
                }}
                onClick={onClick}
                height={200}
            />
        </div>
    );
};

export default ReportChart;
