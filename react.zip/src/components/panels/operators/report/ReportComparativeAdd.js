import { useState, useEffect } from 'react';
import { Row, Col, Spin, Form, Input, Select, Button, Divider } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import {
    DatePicker as DatePickerJalali,
    useJalaliLocaleListener,
} from 'antd-jalali';
import { PlusOutlined } from '@ant-design/icons';

const { Option } = Select;

const ReportComparativeAdd = ({ operational }) => {
    useJalaliLocaleListener();
    const [loading, setLoading] = useState(false);
    const [locativeGroupList, setLocativeGroupList] = useState([]);
    const [headerList, setHeaderList] = useState([]);
    const [feeList, setFeeList] = useState([]);
    const [fetchFeeFlag, setFetchFeeFlag] = useState(false);
    const [form] = Form.useForm();

    const [parts, setParts] = useState([]);
    const [type, setType] = useState(['locative']);

    useEffect(async () => {
        try {
            const res = await axios.all([
                axios.get('parking_spot/locative_group/'),
                axios.get('reports/query_generator_headers/'),
                // axios.get('parking_spot/fee/'),
            ]);

            console.log(res);
            setLocativeGroupList(res[0].results);
            setHeaderList(res[1].query_generator_headers);
            // setFeeList(res[2].results);
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    const onTypeChange = async (value, num) => {
        setType((type) => {
            let newType = [...type];
            newType[num] = value;
            return newType;
        });

        if (value === 'car_plates') {
            if (!fetchFeeFlag) {
                try {
                    const { results } = await axios.get('parking_spot/fee/');
                    setFeeList(results);
                    setFetchFeeFlag(true);
                } catch (error) {
                    notify.danger(error);
                }
            }
        }
    };

    const onFinish = async (values) => {
        const ar = Object.values(values.lines);
        delete values.lines;

        ar.forEach((item, i) => {
            if (!item.selected_fees) {
                item.selected_fees = [];
            }

            // add order
            item.order = i + 1;

            if (operational) {
                item.start = item.start.format('YYYY-MM-DD HH:mm');
                item.end = item.end.format('YYYY-MM-DD HH:mm');
            }
        });

        values.lines = ar;

        console.log(values);

        try {
            await axios.post('reports/comparitive_profiles/', values);
            notify.success();
            form.resetFields();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    const addPart = () => {
        setParts([...parts, Part]);
    };

    // const changeName = (num) => {
    //     setName((name) => {
    //         let newName = [...name];
    //         newName[num] =
    //             newName[num] === 'ali' || !newName[num] ? 'mina' : 'ali';
    //         return newName;
    //     });
    // };

    return (
        <Row align='center'>
            <Col span={20}>
                <br />
                <Spin spinning={loading}>
                    <Form
                        labelCol={{ span: 8 }}
                        wrapperCol={{ span: 24 }}
                        onFinish={onFinish}
                        autoComplete='off'
                        form={form}
                    >
                        <Form.Item
                            label={t('profile')}
                            name='name'
                            rules={[
                                {
                                    required: true,
                                },
                            ]}
                        >
                            <Input />
                        </Form.Item>

                        <Form.Item
                            name='type_of_chart_points_in_result'
                            label={t('report_period')}
                            rules={[{ required: true }]}
                        >
                            <Select>
                                <Option value='monthly' key={1}>
                                    {t('monthly')}
                                </Option>
                                <Option value='daily' key={2}>
                                    {t('daily')}
                                </Option>
                                <Option value='hourly' key={3}>
                                    {t('hourly')}
                                </Option>
                            </Select>
                        </Form.Item>

                        {parts.map((part, num) => {
                            return (
                                <>
                                    <Part
                                        onTypeChange={(value) =>
                                            onTypeChange(value, num)
                                        }
                                        num={num}
                                        data={{
                                            feeList,
                                            locativeGroupList,
                                            headerList,
                                        }}
                                        type={type[num]}
                                        operational={operational}
                                    />
                                </>
                            );
                        })}
                        <div className='modal-footer'>
                            <Button onClick={addPart}>
                                <PlusOutlined />
                            </Button>
                            <Form.Item>
                                <br />
                                <Button
                                    type='primary'
                                    htmlType='submit'
                                    className='wide-button'
                                >
                                    {t('add')}
                                </Button>
                            </Form.Item>
                        </div>
                    </Form>
                </Spin>
            </Col>
        </Row>
    );
};

const Part = ({ onTypeChange, num, data, type, operational }) => {
    const operators = [
        { title: '>', value: 'less' },
        { title: '<', value: 'greater' },
        { title: '=', value: 'equals' },
        { title: '!=', value: 'nequal' },
        { title: 'in', value: 'in' },
    ];

    return (
        <>
            <Divider orientation='center'></Divider>
            <Form.Item
                label={t('label')}
                name={['lines', [num], 'line_name']}
                rules={[
                    {
                        required: true,
                    },
                ]}
            >
                <Input />
            </Form.Item>

            <Form.Item
                name={['lines', [num], 'type']}
                label={t('type')}
                rules={[{ required: true }]}
                initialValue='locative'
            >
                <Select onChange={onTypeChange}>
                    <Option value='locative' key={1}>
                        {t('parking_spots')}
                    </Option>
                    <Option value='car_plates' key={2}>
                        {t('plate_number')}
                    </Option>
                </Select>
            </Form.Item>

            <Form.Item
                name={['lines', [num], 'selected_locative_groups']}
                label={t('locative_group_name')}
                rules={[{ required: true }]}
            >
                <Select mode='multiple' className='multiple-select'>
                    {data.locativeGroupList.map((item) => {
                        return (
                            <Option value={item.id} key={item.id}>
                                {item.title}
                            </Option>
                        );
                    })}
                </Select>
            </Form.Item>

            {type === 'car_plates' && (
                <Form.Item
                    name={['lines', [num], 'selected_fees']}
                    label={t('tariff')}
                    rules={[{ required: true }]}
                >
                    <Select mode='multiple' className='multiple-select'>
                        {data.feeList.map((item) => {
                            return (
                                <Option value={item.id} key={item.id}>
                                    {item.title}
                                </Option>
                            );
                        })}
                    </Select>
                </Form.Item>
            )}
            <Form.Item
                name={['lines', [num], 'headers']}
                label={t('with_show')}
                rules={[{ required: true }]}
            >
                <Select>
                    {data.headerList.map((item) => {
                        return (
                            <Option value={item} key={item}>
                                {item}
                            </Option>
                        );
                    })}
                </Select>
            </Form.Item>

            <Form.Item
                name={['lines', [num], 'operator']}
                label={t('_operator')}
                rules={[{ required: true }]}
            >
                <Select>
                    {operators.map((item, i) => {
                        return (
                            <Option value={item.value} key={i}>
                                {item.title}
                            </Option>
                        );
                    })}
                </Select>
            </Form.Item>

            {operational && (
                <>
                    <Form.Item
                        label={t('start')}
                        name={['lines', [num], 'start']}
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                    >
                        <DatePickerJalali showTime format='YYYY-MM-DD HH:mm' />
                    </Form.Item>

                    <Form.Item
                        label={t('end')}
                        name={['lines', [num], 'end']}
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                    >
                        <DatePickerJalali showTime format='YYYY-MM-DD HH:mm' />
                    </Form.Item>
                </>
            )}
        </>
    );
};

export default ReportComparativeAdd;
