import { useState, useEffect } from 'react';
import { Row, Col, Spin, Form, Input, Select, Button, Divider } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import {
    DatePicker as DatePickerJalali,
    useJalaliLocaleListener,
} from 'antd-jalali';

const { Option } = Select;

const ReportDetailedAdd = ({ operational }) => {
    useJalaliLocaleListener();
    const [loading, setLoading] = useState(false);
    const [locativeGroupList, setLocativeGroupList] = useState([]);
    const [headerList, setHeaderList] = useState([]);
    const [feeList, setFeeList] = useState([]);
    const [type, setType] = useState('parking_spot');
    const [fetchFeeFlag, setFetchFeeFlag] = useState(false);
    const [form] = Form.useForm();

    useEffect(async () => {
        try {
            const res = await axios.all([
                axios.get('parking_spot/locative_group/'),
                axios.get('reports/query_generator_headers/'),
                // axios.get('parking_spot/fee/'),
            ]);

            console.log(res);
            setLocativeGroupList(res[0].results);
            setHeaderList(res[1].query_generator_headers);
            // setFeeList(res[2].results);
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    const onTypeChange = async (value) => {
        if (value === 'car_plates') {
            if (!fetchFeeFlag) {
                try {
                    const { results } = await axios.get('parking_spot/fee/');
                    setFeeList(results);
                    setFetchFeeFlag(true);
                } catch (error) {
                    notify.danger(error);
                }
            }
        }

        setType(value);
    };

    const onFinish = async (values) => {
        if (!values.lines.selected_fees) {
            values.lines.selected_fees = [];
        }

        if (operational) {
            values.lines.start = values.lines.start.format('YYYY-MM-DD HH:mm');
            values.lines.end = values.lines.end.format('YYYY-MM-DD HH:mm');
        }

        try {
            await axios.post('reports/profiles/', values);
            notify.success();
            form.resetFields();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <Row align='center'>
            <Col span={20}>
                <Spin spinning={loading}>
                    <Form
                        labelCol={{ span: 6 }}
                        wrapperCol={{ span: 24 }}
                        onFinish={onFinish}
                        autoComplete='off'
                        form={form}
                    >
                        <br />
                        {/* <Divider orientation='center'>اطلاعات پایه</Divider> */}
                        <Form.Item
                            label={t('profile')}
                            name='name'
                            rules={[
                                {
                                    required: true,
                                },
                            ]}
                        >
                            <Input />
                        </Form.Item>

                        <Form.Item
                            label={t('label')}
                            name={['lines', 'line_name']}
                            rules={[
                                {
                                    required: true,
                                },
                            ]}
                        >
                            <Input />
                        </Form.Item>

                        {/* <Divider orientation='center'>اطلاعات گزارش</Divider> */}
                        <Form.Item
                            name={['lines', 'type']}
                            label={t('type')}
                            rules={[{ required: true }]}
                            initialValue='parking_spot'
                        >
                            <Select onChange={onTypeChange}>
                                <Option value='parking_spot' key={1}>
                                    {t('parking_spots')}
                                </Option>
                                <Option value='car_plates' key={2}>
                                    {t('plate_number')}
                                </Option>
                            </Select>
                        </Form.Item>

                        <Form.Item
                            name={['lines', 'selected_locative_groups']}
                            label={t('locative_group_name')}
                            rules={[{ required: true }]}
                        >
                            <Select mode='multiple' className='multiple-select'>
                                {locativeGroupList.map((item) => {
                                    return (
                                        <Option value={item.id} key={item.id}>
                                            {item.title}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>

                        {type === 'car_plates' && (
                            <Form.Item
                                name={['lines', 'selected_fees']}
                                label={t('tariff')}
                                rules={[{ required: true }]}
                            >
                                <Select
                                    mode='multiple'
                                    className='multiple-select'
                                >
                                    {feeList.map((item) => {
                                        return (
                                            <Option
                                                value={item.id}
                                                key={item.id}
                                            >
                                                {item.title}
                                            </Option>
                                        );
                                    })}
                                </Select>
                            </Form.Item>
                        )}

                        <Form.Item
                            name={['lines', 'headers']}
                            label={t('with_show')}
                            rules={[{ required: true }]}
                        >
                            <Select>
                                {headerList.map((item) => {
                                    return (
                                        <Option value={item} key={item}>
                                            {item}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>

                        <Form.Item
                            name='type_of_chart_points_in_result'
                            label={t('report_period')}
                            rules={[{ required: true }]}
                        >
                            <Select>
                                <Option value='monthly' key={1}>
                                    {t('monthly')}
                                </Option>
                                <Option value='daily' key={2}>
                                    {t('daily')}
                                </Option>
                                <Option value='hourly' key={3}>
                                    {t('hourly')}
                                </Option>
                            </Select>
                        </Form.Item>
                        {operational && (
                            <>
                                <Divider orientation='center'>زمانبندی</Divider>

                                <Form.Item
                                    label={t('start')}
                                    name={['lines', 'start']}
                                    rules={[
                                        {
                                            required: true,
                                        },
                                    ]}
                                >
                                    <DatePickerJalali
                                        showTime
                                        format='YYYY-MM-DD HH:mm'
                                    />
                                </Form.Item>

                                <Form.Item
                                    label={t('end')}
                                    name={['lines', 'end']}
                                    rules={[
                                        {
                                            required: true,
                                        },
                                    ]}
                                >
                                    <DatePickerJalali
                                        showTime
                                        format='YYYY-MM-DD HH:mm'
                                    />
                                </Form.Item>
                            </>
                        )}

                        <div className='modal-footer'>
                            <Form.Item>
                                <Button
                                    type='primary'
                                    htmlType='submit'
                                    className='wide-button'
                                >
                                    {t('add')}
                                </Button>
                            </Form.Item>
                        </div>
                    </Form>
                </Spin>
            </Col>
        </Row>
    );
};

export default ReportDetailedAdd;
