import React, { useState } from 'react';
import t from 'helpers/translation';
import { Row, Col, Card, Select } from 'antd';
import ReportDetailedAdd from 'components/panels/operators/report/ReportDetailedAdd';
import ReportComparativeAdd from 'components/panels/operators/report/ReportComparativeAdd';

const { Option } = Select;

const ReportSelect = () => {
    const [cardContent, setCardContent] = useState();

    const onSelectChange = (value) => {
        switch (value) {
            case 1:
                setCardContent(<ReportDetailedAdd operational={false} />);
                return;
            case 2:
                setCardContent(<ReportComparativeAdd operational={false} />);
                return;
            case 3:
                setCardContent(<ReportDetailedAdd operational={true} />);
                return;
            case 4:
                setCardContent(<ReportComparativeAdd operational={true} />);
                return;
            default:
                return null;
        }
    };

    return (
        <Row align='center'>
            <Col xs={23} sm={18} md={15} lg={14} xl={12}>
                <Card
                    title={t('add_report')}
                    className='report-card'
                    extra={
                        <Select
                            style={{ width: 170 }}
                            onChange={onSelectChange}
                        >
                            <Option key='1' value={1}>
                                {t('membership-detailed')}
                            </Option>
                            <Option key='2' value={2}>
                                {t('membership-comparative')}
                            </Option>
                            <Option key='3' value={3}>
                                {t('operational-detailed')}
                            </Option>
                            <Option key='4' value={4}>
                                {t('operational-comparative')}
                            </Option>
                        </Select>
                    }
                >
                    {cardContent}
                </Card>
            </Col>
        </Row>
    );
};

export default ReportSelect;
