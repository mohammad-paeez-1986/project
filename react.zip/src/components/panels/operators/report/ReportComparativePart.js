import React, { useState } from 'react';
import { Form, Input, Select, Divider } from 'antd';
import t from 'helpers/translation';
const { Option } = Select;

const ReportComparativePart = ({
    lineCounter,
    feeList,
    headerList,
    locativeGroupList,
}) => {
    const [type, setType] = useState('parking_spot');

    const onTypeChange = (value) => {
        console.log(value);
    };

    // console.log(locativeGroupList);

    return (
        <>
            {/* <Divider orientation='center'>
                اطلاعات گزارش {lineCounter + 1}
            </Divider> */}
            <Form.Item
                label={t('label')}
                name={['lines', 'line_name']}
                rules={[
                    {
                        required: true,
                    },
                ]}
            >
                <Input />
            </Form.Item>
            <Form.Item
                name={['lines', [lineCounter], ['type']]}
                label={t('type')}
                rules={[{ required: true }]}
                initialValue='parking_spot'
            >
                <Select onChange={onTypeChange}>
                    <Option value='parking_spot' key={1}>
                        {t('parking_spots')}
                    </Option>
                    <Option value='car_plates' key={2}>
                        {t('plate_number')}
                    </Option>
                </Select>
            </Form.Item>

            {/* <Form.Item
                name={['lines', 'selected_locative_groups']}
                label={t('locative_group_name')}
                rules={[{ required: true }]}
            >
                <Select mode='multiple' className='multiple-select'>
                    {locativeGroupList.map((item) => {
                        return (
                            <Option value={item.id} key={item.id}>
                                {item.title}
                            </Option>
                        );
                    })}
                </Select>
            </Form.Item> */}

            {/* {type === 'car_plates' && (
                <Form.Item
                    name={['lines', 'selected_fees']}
                    label={t('tariff')}
                    rules={[{ required: true }]}
                >
                    <Select mode='multiple' className='multiple-select'>
                        {feeList.map((item) => {
                            return (
                                <Option value={item.id} key={item.id}>
                                    {item.title}
                                </Option>
                            );
                        })}
                    </Select>
                </Form.Item>
            )}

            <Form.Item
                name={['lines', 'headers']}
                label={t('with_show')}
                rules={[{ required: true }]}
            >
                <Select>
                    {headerList.map((item) => {
                        return (
                            <Option value={item} key={item}>
                                {item}
                            </Option>
                        );
                    })}
                </Select>
            </Form.Item>

            <Form.Item
                name='type_of_chart_points_in_result'
                label={t('report_period')}
                rules={[{ required: true }]}
            >
                <Select>
                    <Option value='monthly' key={1}>
                        {t('monthly')}
                    </Option>
                    <Option value='daily' key={2}>
                        {t('daily')}
                    </Option>
                    <Option value='hourly' key={3}>
                        {t('hourly')}
                    </Option>
                </Select>
            </Form.Item>*/}
        </>
    );
};

export default ReportComparativePart;
