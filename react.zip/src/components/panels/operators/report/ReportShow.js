import React, { useState, useEffect } from 'react';
import t from 'helpers/translation';
import { Row, Col, Card, Select, Button } from 'antd';
import { PlusOutlined, MinusOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import notify from 'helpers/notify';
import ReportChart from 'components/panels/operators/report/ReportChart';

const { Option } = Select;

const ReportShow = ({ doHighLight, toggleDrawer }) => {
    const [comparativeObjectList, setComparativeObjectList] = useState([]);
    const [selectLoading, setSelectLoading] = useState(false);
    const [selectedObjectData, setSelectedObjectData] = useState(null);

    const navigate = useNavigate();

    // get comparative objects
    useEffect(async () => {
        setSelectLoading(true);

        try {
            const { results } = await axios.get(
                'reports/comparitive_profiles/'
            );
            setComparativeObjectList(results);
        } catch (error) {
            notify.danger(error);
        }

        setSelectLoading(false);
    }, []);

    const onSelectChange = (id) => {
        const data = comparativeObjectList.find((item) => item.id === id);
        setSelectedObjectData(data);
    };

    return (
        <div className='histogeram-container'>
            <div className='open-histogeram-bar'>
                <MinusOutlined
                    className='open-histogeram-bar histogram-bar-step'
                    onClick={toggleDrawer}
                />
            </div>
            <div className='chart-select-wrapper'>
                <Select
                    className='chart-select'
                    style={{ width: 160 }}
                    loading={selectLoading}
                    onChange={onSelectChange}
                >
                    {comparativeObjectList.map(({ id, name }) => (
                        <Option key={id} value={id}>
                            {name}
                        </Option>
                    ))}
                </Select>
                <Button
                    size='small'
                    onClick={() => navigate('/operators/reports')}
                >
                    <PlusOutlined />
                </Button>
            </div>

            {selectedObjectData && (
                <ReportChart
                    object={selectedObjectData}
                    id={selectedObjectData.id}
                    doHighLight={doHighLight}
                />
            )}
        </div>
    );
};

export default ReportShow;
