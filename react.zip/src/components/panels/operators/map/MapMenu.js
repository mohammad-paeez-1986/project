import React, { useState, useContext } from 'react';
import { Slider } from 'antd';
import {
    MenuFoldOutlined,
    LogoutOutlined,
    BarChartOutlined,
    ContactsOutlined,
    QuestionCircleOutlined,
} from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import { MapContext } from 'contexts/MapContext';
import Tour from 'reactour';

const style = {
    display: 'inline-block',
    height: 300,
    marginLeft: 10,
};

const steps = [
    {
        selector: '.histogeram-step',
        content: 'Show histogeram chart',
    },
    {
        selector: '.profiles-step',
        content: 'Show profiles',
    },
    {
        selector: '.histogram-bar-step',
        content: 'Show histogeram chart',
    },
    {
        selector: '.floor-step',
        content: 'Choose floor to load map',
    },
    {
        selector: '.zoom-step',
        content: 'Set zoom of map',
    },
    {
        selector: '.select-group-step',
        content:
            'Click here, Then choose parking spots, corridors, led`s or cameras on map to edit',
    },
];

const MapMenu = ({ toggleDrawer }) => {
    const [tourVisible, setTourVisible] = useState(false);
    const [map] = useContext(MapContext);

    const navigate = useNavigate();

    return (
        <div className='map-menu-wrapper'>
            <Tour
                steps={steps}
                isOpen={tourVisible}
                startAt={0}
                onRequestClose={() => setTourVisible(false)}
            />
            <div className='map-menu-container'>
                {/* <MenuFoldOutlined />
                <LogoutOutlined /> */}
                {/* <br /> */}
                <QuestionCircleOutlined onClick={() => setTourVisible(true)} />
                <BarChartOutlined
                    onClick={toggleDrawer}
                    className='histogeram-step'
                />
                <ContactsOutlined
                    onClick={() => navigate('/operators/profiles')}
                    className='profiles-step'
                />
                <br />
                <p style={style} className='zoom-step'>
                    <Slider
                        vertical
                        step={0.5}
                        min={0}
                        max={10}
                        defaultValue={2.5}
                        onChange={(e) => map.setZoom(e)}
                    />
                </p>
            </div>
        </div>
    );
};

export default MapMenu;
