import React, { useState, useEffect, useRef } from 'react';
import { MapContainer, LayersControl, GeoJSON } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import config from 'config/geoserver.json';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import { Select, Empty } from 'antd';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import ReportShow from 'components/panels/operators/report/ReportShow';
import { BarChartOutlined } from '@ant-design/icons';

const { Option } = Select;

const MapComponent = ({
    toggleDrawer,
    doHighLight,
    selectList,
    selectType,
    openParkShowModal,
    openCorridorWeighModal,
    highlightList,
    // vacantSpotList,
    // occupiedSpotList,
    // outSpotList,
    emptyConditionList,
    occupiedSpotList,
    setOccupiedSpotList,
    vacantSpotList,
    setVacantSpotList,
    outSpotList,
    setOutSpotList,
}) => {
    const [map, setMap] = useState(null);
    const [featuresList, setFeaturesList] = useState([]);
    const [floors, setFloors] = useState([]);
    const [selectedFloor, setSelectedFloor] = useState('');
    const [selectLoading, setSelectLoading] = useState(false);
    const [refresh, setRefresh] = useState(true);
    // const [zoomControl, setZoomControl] = useState(false);

    const groupSelectButtonElement =
        document.getElementById('group-select-btn');
    const selectListCountElement = document.getElementById('select-list-count');

    const SetLayerOptions = (name) => {
        if (name.substr(0, 6) === 'camera') {
            name = 'camera';
        }

        L.Marker.prototype.options.icon = L.icon({
            iconUrl: process.env.PUBLIC_URL + '/assets/images/' + name + '.png',
        });
    };

    // http://${url}/api/parking_spot/parking_spot/?name&parking_condition=2&camera&priority&properties_floor=-3
    const getFullSpots = async (floorNum) => {
        // empty

        try {
            const { results } = await axios.get(
                // for -4 nothing data
                `parking_spot/parking_spot/?properties_floor=${floorNum}&limit=1000`
            );

            emptyConditionList();

            let vacantSpotArray = [];
            let occupiedSpotArray = [];
            let outSpotArray = [];

            results.forEach((item) => {
                switch (item?.parking_condition) {
                    case 1:
                        // vacantSpotList.current.push(item.id);
                        vacantSpotArray.push(item.id);
                        break;
                    case 2:
                        // occupiedSpotList.current.push(item.id);
                        occupiedSpotArray.push(item.id);
                        break;
                    case 3:
                        // outSpotList.current.push(item.id);
                        // console.log(item.id);
                        outSpotArray.push(item.id);
                        break;
                    default:
                        break;
                }
            });

            setVacantSpotList(vacantSpotArray);
            setOccupiedSpotList(occupiedSpotArray);
            setOutSpotList(outSpotArray);
            // console.log(occupiedSpotArray);
        } catch (error) {
            notify.danger(error);
        }
    };

    // set floors and default icon
    useEffect(() => {
        const floorArray = config.shape_files.map((item) => item.floor);
        setFloors(floorArray);
    }, []);

    const loadLayers = async (floorNum) => {
        doHighLight([]);

        setSelectLoading(true);
        await getFullSpots(floorNum);

        const floor = await config.shape_files.find(
            (item) => item.floor == floorNum
        );

        let layers;
        if (floor) {
            layers = Object.values(floor.layers);
        } else {
            return;
        }

        if (layers && layers.length > 0) {
            selectList.current = [];
            selectType.current = '';
            setFeaturesList([]);
            layers.map((layer) => {
                if (layer !== 'fisheye') {
                    fetch(
                        `http://194.5.175.154:8090/geoserver/${floor.workspace.trim()}/wfs?outputFormat=application/json&request=GetFeature&service=WFS&typeName=parsis:${layer}&version=1.0.0`
                    )
                        .then((res) => res.json())
                        .then((res) => {
                            let features = res.features;

                            if (features.length > 0) {
                                // map?.zoomControl.enable();
                                // document.querySelector(
                                //     '.leaflet-control-zoom'
                                // ).style.display = 'inline';
                                map?.scrollWheelZoom.enable();
                            } else {
                                // document.querySelector(
                                //     '.leaflet-control-zoom'
                                // ).style.display = 'none';
                                // // map?.zoomControl.disable();
                                map?.scrollWheelZoom.disable();
                            }

                            features = features.map((item) => {
                                // Ø®Ø§ÙÛ
                                // Ù¾Ø±

                                item.properties.popupContent = item.id;
                                return item;
                            });

                            // add icon
                            SetLayerOptions(layer);

                            setFeaturesList((featuresList) => [
                                ...featuresList,
                                { [layer]: features },
                            ]);
                        })
                        .catch((e) => {
                            console.log(e);
                        });
                }
            });
        }
        setSelectLoading(false);
    };

    const getSelectType = (layerId) => {
        switch (true) {
            case layerId.startsWith('park'):
                return 'park';
            case layerId.startsWith('path'):
                return 'path';
        }
    };

    function onEachFeature(feature, layer) {
        if (feature.properties) {
            // bind popup
            if (feature.properties?.popupContent) {
                layer.bindPopup(feature.properties?.popupContent);
            }

            layer.on('mouseout', () => {
                layer.closePopup();
            });

            // add click bind
            const layerId = feature.properties?.name;

            // if (layerId?.startsWith('park')) {
            //     switch (true) {
            //         case occupiedSpotList?.current.indexOf(
            //             feature.properties.Id
            //         ) !== -1:
            //             layer.setStyle({
            //                 fillColor: '#ca2727',
            //                 fillOpacity: bb36364,
            //                 // className:'vacant'
            //             });
            //             break;
            //         case outSpotList?.current.indexOf(feature.properties.Id) !==
            //             -1:
            //             layer.setStyle({
            //                 fillColor: '#ccc',
            //                 color: '#888',
            //                 opacity: 0.5,
            //                 fillOpacity: 0.8,
            //                 // className:'vacant'
            //             });
            //             break;
            //         default:
            //             break;
            //     }
            // }

            if (
                layerId?.startsWith('park') ||
                layerId?.startsWith('path') ||
                layerId?.startsWith('LED')
            ) {
                layer.on('click', () => {
                    if (
                        groupSelectButtonElement?.dataset?.clickMode === 'click'
                    ) {
                        const id = feature.properties.Id;
                        if (layerId?.startsWith('park')) {
                            openParkShowModal(id);
                        } else if (layerId?.startsWith('path')) {
                            openCorridorWeighModal(id);
                        }
                    } else if (
                        groupSelectButtonElement?.dataset?.clickMode ===
                        'select'
                    ) {
                        // SELECT MODE
                        if (
                            layerId?.startsWith('park') ||
                            layerId?.startsWith('path')
                        ) {
                            const Id = layer.feature?.properties?.Id;

                            if (
                                !selectType.current ||
                                selectType.current == getSelectType(layerId)
                            ) {
                                if (
                                    // layer.options.color === 'rgb(51, 136, 255)'
                                    layer.options.color !== '#fd7b24'
                                ) {
                                    // add to list

                                    if (!selectType.current) {
                                        selectType.current =
                                            getSelectType(layerId);
                                    }

                                    layer.setStyle({
                                        color: '#fd7b24',
                                        fillColor: '#fd7b24',
                                    });
                                    if (Id) {
                                        selectList.current.push(layer);
                                        selectListCountElement.innerHTML = `${t(
                                            'edit'
                                        )} (${selectList.current.length})`;
                                    }
                                } else {
                                    // remove from list
                                    layer.setStyle({
                                        color: 'rgb(51, 136, 255)',
                                        fillColor: null,
                                    });
                                    if (Id) {
                                        const newSelectList =
                                            selectList.current.filter(
                                                (item) => item !== layer
                                            );

                                        selectList.current = newSelectList;

                                        if (selectList.current.length === 0) {
                                            selectListCountElement.innerHTML =
                                                null;
                                        }
                                    }
                                }
                            } else {
                                selectList.current.map((item) => {
                                    item.setStyle({
                                        color: 'rgb(51, 136, 255)',
                                        fillColor: null,
                                    });
                                });
                                selectList.current = [layer];
                                selectType.current = getSelectType(layerId);
                                layer.setStyle({
                                    color: '#fd7b24',
                                    fillColor: '#fd7b24',
                                });
                                selectListCountElement.innerHTML = `${t(
                                    'edit'
                                )} (${selectList.current.length})`;
                            }
                        }

                        // else if (layerId?.startsWith('LED')) {
                        //     const ic = L.Icon.extend({
                        //         options: {
                        //             iconUrl:
                        //                 process.env.PUBLIC_URL +
                        //                 '/assets/images/led-selected.png',
                        //         },
                        //     });
                        //     layer.setIcon(new ic());
                        //     console.log(layer);
                        // }
                    }
                });
            }
        }
    }

    const onFloorChange = (e) => {
        loadLayers(e);
    };

    const emptyS = () => {
        // vacantSpotList.current = [1, 4, 5, 7, 89];
        // occupiedSpotList.current = [2, 78, 45, 32, 46, 89];
        // outSpotList.current = [34, 67, 13, 5];
        // setFlist((flist) => []);
        // setRefresh(!refresh);
        // setOccupiedSpotList([])
        // console.log(occupiedSpotList.current);
    };

    const onMapStyle = (s) => {
        // if is parking and id is in highlightList
        if (
            // highlightList.length &&
            // s.properties.Layer === 'parking' &&
            highlightList.indexOf(s.properties.OBJECTID) != -1
        ) {
            return {
                color: '#021',
            };
        }

        // all but if is not in slelectList
        // console.log(fList);
        if (occupiedSpotList.indexOf(s.properties.OBJECTID) != -1) {
            return {
                // fillOpacity: 0.4,
                fillColor: '#ca2727',
                color: '#bb3636',
            };
        }

        if (outSpotList.indexOf(s.properties.OBJECTID) != -1) {
            return {
                fillColor: '#ccc',
                color: '#aaa',
                // opacity: 0.5,
                // fillOpacity: 0.8,
            };
        }

        const idList = selectList.current.map((item) => {
            const id = item?.feature?.properties?.Id;
            if (id) {
                return id;
            }
        });

        // if not exists in idList, selectList
        if (idList.indexOf(s.properties.Id) == -1) {
            return {
                color: 'rgb(51, 136, 255)',
                fillColor: null,
            };
        }

        // else {
        //     const idList = selectList.current.map((item) => {
        //         const id = item?.feature?.properties?.Id;
        //         if (id) {
        //             return id;
        //         }
        //     });

        //     if (
        //         [
        //             ...idList,
        //             ...occupiedSpotList.current,
        //             ...outSpotList.current,
        //         ].indexOf(s.properties.Id) === -1
        //     ) {
        //         return {
        //             color: 'rgb(51, 136, 255)',
        //         };
        //     }
        // }
    };

    return (
        <MapContainer
            id='map'
            ref={setMap}
            zoom={2.5}
            center={[19.897240250321865, 432.57545592420996]}
        >
            {/* <p onClick={emptyS}>empty s</p> */}
            <LayersControl.Overlay>
                <Select
                    loading={selectLoading}
                    style={{ width: 120, zIndex: 900 }}
                    className='floor-select'
                    placeholder={t('floor')}
                    onChange={onFloorChange}
                >
                    {floors.map((item) => (
                        <Option key={item} value={item}>
                            {item}
                        </Option>
                    ))}
                </Select>
                {featuresList.length ? (
                    <p className='histogeram' onClick={toggleDrawer}>
                        <BarChartOutlined />
                    </p>
                ) : (
                    ''
                )}
            </LayersControl.Overlay>
            {featuresList && featuresList.length > 0 ? (
                <LayersControl position={'topleft'}>
                    {featuresList.map((features) => (
                        <LayersControl.Overlay
                            checked
                            // key={Object.keys(features)[0].id}
                            name={Object.keys(features)[0]}
                        >
                            <GeoJSON
                                data={Object.values(features)[0]}
                                // markersInheritOptions={true}
                                onEachFeature={onEachFeature}
                                style={onMapStyle}
                            />
                        </LayersControl.Overlay>
                    ))}
                </LayersControl>
            ) : (
                <Empty className='map-placeholder' />
            )}
        </MapContainer>
    );
};

export default React.memo(MapComponent);
