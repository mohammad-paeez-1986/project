import React, { useState, useEffect, useRef } from 'react';
import { MapContainer, LayersControl, GeoJSON } from 'react-leaflet';
// import { useMapEvents } from 'react-leaflet/hooks'
import { useMapEvents } from 'react-leaflet/hooks';

import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import config from 'config/geoserver.json';

import t from 'helpers/translation';
import { Select, Empty, Modal, Drawer, Button } from 'antd';
import ParkShow from 'components/panels/operators/map/ParkShow';
import MapComponent from 'components/panels/operators/map/MapComponent';
import CorridorEdit from 'components/panels/operators/map/corridor/CorridorEdit';
import CorridorWeightEdit from 'components/panels/operators/map/corridor/CorridorWeightEdit';
import ParkingSpotEdit from 'components/panels/operators/map/parking-spot/ParkingSpotEdit';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import ReportShow from 'components/panels/operators/report/ReportShow';
import { BarChartOutlined } from '@ant-design/icons';

const { Option } = Select;

const MapShow = () => {
    const [selectedId, setSelectedId] = useState(null);
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [modalTitle, setModalTitle] = useState('');
    const [modalContent, setModalContent] = useState(null);
    const [modalWidth, setModalWidth] = useState(376);
    const [highlightList, setHighlightList] = useState([]);
    const [drawerVisible, setDrawerVisible] = useState(false);
    const [clickMode, setClickMode] = useState('click');
    const [count, setCount] = useState(0);
    const [refresh, setRefresh] = useState(false);
    
    const selectList = useRef([]);
    const selectType = useRef('');
    // const vacantSpotList = useRef([]);
    // const occupiedSpotList = useRef([]);
    // const outSpotList = useRef([]);

    const [occupiedSpotList, setOccupiedSpotList] = useState([]);
    const [vacantSpotList, setVacantSpotList] = useState([]);
    const [outSpotList, setOutSpotList] = useState([]);

    const groupSelectButtonElement =
        document.getElementById('group-select-btn');
    const selectListCountElement = document.getElementById('select-list-count');

    const toggleClickMode = () => {
        if (groupSelectButtonElement.dataset.clickMode === 'click') {
            setClickMode('select');
            groupSelectButtonElement.dataset.clickMode = 'select';
        } else {
            emptySelectList();
            setClickMode('click');
            groupSelectButtonElement.dataset.clickMode = 'click';
        }
    };

    const getSelectType = (layerId) => {
        switch (true) {
            case layerId.startsWith('park'):
                return 'park';
            case layerId.startsWith('path'):
                return 'path';
        }
    };

    const emptySelectList = () => {
        selectList.current = [];
        selectListCountElement.innerHTML = null;
    };

    const onGroupEdit = () => {
        if (selectList.current.length) {
            setModalWidth(567);
            setIsModalVisible(true);
            if (selectType.current === 'path') {
                setModalContent(
                    <CorridorEdit
                        list={selectList.current}
                        closeModal={closeModal}
                        emptySelectList={emptySelectList}
                    />
                );
                setModalTitle(t('edit_for_path'));
            } else if (selectType.current === 'park') {
                setModalContent(
                    <ParkingSpotEdit
                        list={selectList.current}
                        closeModal={closeModal}
                        emptySelectList={emptySelectList}
                    />
                );
                setModalTitle(t('edit_for_park'));
            }
        }
    };

    const closeModal = () => {
        setIsModalVisible(false);
    };

    const onDrawerClose = () => {
        setDrawerVisible(false);
        setHighlightList([]);
    };

    const doHighLight = (list) => {
        setHighlightList(list);
    };

    const toggleDrawer = () => {
        setDrawerVisible(!drawerVisible);
        setHighlightList([]);
    };

    const emptyConditionList = () => {
        setVacantSpotList([]);
        setOccupiedSpotList([]);
        setOutSpotList([]);
    };

    const changeParkCondition = (fromCondition, to, id) => {
        // 1:vacant, 2:occupied, 3:out

        let index;
        switch (fromCondition) {
            case 1:
                index = vacantSpotList.indexOf(id);
                if (index) {
                    vacantSpotList.splice(index, 1);
                }
                break;
            case 2:
                index = occupiedSpotList.indexOf(id);
                if (index) {
                    occupiedSpotList.splice(index, 1);
                }
                break;
            case 3:
                index = outSpotList.indexOf(id);
                if (index) {
                    outSpotList.splice(index, 1);
                }
                break;
            default:
                break;
        }

        switch (to) {
            case 1:
                vacantSpotList.push(id);
                break;
            case 2:
                occupiedSpotList.push(id);
                break;
            case 3:
                outSpotList.push(id);
                break;
            default:
                break;
        }
    };

    const openParkShowModal = (id) => {
        setSelectedId(id);
        setModalWidth(1024);
        setIsModalVisible(true);
        setModalContent(
            <ParkShow id={id} changeParkCondition={changeParkCondition} />
        );
        setModalTitle(t('park_place', { number: id }));
    };

    const openCorridorWeighModal = (id) => {
        setModalWidth(560);
        setIsModalVisible(true);
        setModalContent(<CorridorWeightEdit id={id} closeModal={closeModal} />);
        setModalTitle(t('edit_corridor', { number: id }));
    };

    return (
        <>
            {/* <button onClick={() => changeParkCondition(1, 2, 3)}>
                moasdghs
            </button> */}
            <MapComponent
                toggleDrawer={toggleDrawer}
                // onMapStyle={onMapStyle}
                doHighLight={doHighLight}
                highlightList={highlightList}
                selectList={selectList}
                selectType={selectType}
                openParkShowModal={openParkShowModal}
                // vacantSpotList={vacantSpotList}
                // occupiedSpotList={occupiedSpotList}
                // outSpotList={outSpotList}
                emptyConditionList={emptyConditionList}
                vacantSpotList={vacantSpotList}
                setVacantSpotList={setVacantSpotList}
                outSpotList={outSpotList}
                setOutSpotList={setOutSpotList}
                occupiedSpotList={occupiedSpotList}
                setOccupiedSpotList={setOccupiedSpotList}
                openCorridorWeighModal={openCorridorWeighModal}
            />

            <Modal
                title={modalTitle}
                visible={isModalVisible}
                footer={null}
                destroyOnClose={true}
                width={modalWidth}
                onCancel={closeModal}
            >
                {modalContent}
            </Modal>
            <Drawer
                className='chart-drawer'
                placement='left'
                maskStyle={{ display: 'none' }}
                onClose={onDrawerClose}
                visible={drawerVisible}
                afterVisibleChange={(e) => {
                    if (e) {
                        document.body.style.removeProperty('overflow-y');
                        document.body.style.removeProperty('width');
                    }
                }}
            >
                <ReportShow doHighLight={doHighLight} />
            </Drawer>

            <div className='group-select'>
                <Button
                    size='small'
                    id='group-select-btn'
                    onClick={toggleClickMode}
                    data-click-mode={clickMode}
                    {...{ type: clickMode === 'click' ? 'ghost' : 'primary' }}
                >
                    {t('choose')}
                </Button>
                <Button
                    size='small'
                    id='select-list-count'
                    onClick={onGroupEdit}
                ></Button>
            </div>
        </>
    );
};

export default React.memo(MapShow);
