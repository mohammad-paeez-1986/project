import React, { useState, useEffect } from 'react';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import { Row, Col, Form, Spin, Select, Button } from 'antd';

const { Option } = Select;

const CameraSendVoice = ({ list, closeModal, emptySelectList }) => {
    const [selectLoading, setSelectLoading] = useState(true);
    const [loading, setLoading] = useState(false);
    const [voiceList, setVoiceList] = useState([]);
    const [cameraList, setCameraList] = useState([]);

    useEffect(async () => {
        try {
            const { results } = await axios.get(
                'device/device_message/?message_type=2'
            );

            setVoiceList(results);
            setSelectLoading(false);
            // get ids
            const idList = list.map((item) => {
                const id = item?.feature?.properties?.Id;
                if (id) {
                    return id;
                }
            });

            setCameraList(idList);
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    const onFinish = async (values) => {
        values.camera_list = cameraList;

        setLoading(true);

        try {
            const data = await axios.post(
                'camera/camera/bulk_play_voice/',
                values
            );
            notify.success(data);
            emptySelectList();
            closeModal();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <Row align='center'>
            <Col span={18}>
                <Spin spinning={loading}>
                    <Form
                        onFinish={onFinish}
                        autoComplete='off'
                        layout='vertical'
                    >
                        <Form.Item
                            name='message_id'
                            rules={[
                                {
                                    required: true,
                                    message: t('choose_a_voice'),
                                },
                            ]}
                        >
                            <Select>
                                {voiceList.map((item) => (
                                    <Option key={item.id} value={item.id}>
                                        {item.value}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <div className='modal-footer'>
                            <Form.Item>
                                <Button htmlType='submit' type='primary'>
                                    {t('send_voice')}
                                </Button>
                            </Form.Item>
                        </div>
                    </Form>
                </Spin>
            </Col>
        </Row>
    );
};

export default CameraSendVoice;
