import React, { useState, useEffect } from 'react';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import { Row, Col, Form, Select, Button } from 'antd';

const { Option } = Select;

const VoicePart = () => {
    const [selectLoading, setSelectLoading] = useState(true);
    const [voiceList, setVoiceList] = useState([]);

    useEffect(async () => {
        try {
            const { results } = await axios.get(
                'device/device_message/?message_type=2'
            );

            setVoiceList(results);
            setSelectLoading(false);
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    const onFinish = (values) => {
        console.log(values);
    };

    return (
        <Row align='center'>
            <Col span={18}>
                <Form onFinish={onFinish} autoComplete='off' layout='vertical'>
                    <Form.Item
                        name='voice'
                        rules={[
                            {
                                required: true,
                                message: t('choose_a_voice'),
                            },
                        ]}
                    >
                        <Select>
                            {voiceList.map((item) => (
                                <Option key={item.id} value={item.id}>
                                    {item.value}
                                </Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item>
                        <Button htmlType='submit' className='full-button'>
                            {t('send_voice')}
                        </Button>
                    </Form.Item>
                </Form>
            </Col>
        </Row>
    );
};

export default VoicePart;
