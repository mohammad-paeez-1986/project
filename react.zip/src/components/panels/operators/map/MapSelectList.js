import React, { useState, useEffect } from 'react';
import t from 'helpers/translation';
import { Select, Empty, Modal, Drawer, Button } from 'antd';
import {
    UnorderedListOutlined,
    EditOutlined,
    DeleteOutlined,
    CloseOutlined,
} from '@ant-design/icons';

const MapSelectList = ({
    selectListStateArray,
    toggleClickMode,
    clickMode,
    onGroupEdit,
}) => {
    const [selectList, setSelectList] = selectListStateArray;
    const [listByFloorJSX, setListByFloorJSX] = useState();

    useEffect(() => {
        let listByFloor = [];

        selectList.map((item) => {
            const floor = item?.feature?.properties?.floor;

            const floorItem = listByFloor.find((item) => item.floor === floor);

            if (floorItem) {
                floorItem.layers.push(item);
            } else {
                listByFloor.push({
                    floor,
                    layers: [item],
                });
            }
        });

        createListJsx(listByFloor);
    }, [selectList]);

    const deleteFromSelect = (id) => {
        let newSelectList;
        newSelectList = selectList.filter(
            (item) => item?.feature?.properties?.Id !== id
        );
        setSelectList(newSelectList);
    };

    const createListJsx = (list) => {
        const JSX = [];
        const a = list.forEach((item) => {
            JSX.push(
                <p className='floor-title'>
                    {t('floor')} {item.floor}
                </p>
            );
            const list = item.layers.map((element) => (
                <li>
                    {element.feature?.id}{' '}
                    <DeleteOutlined
                        className='icon-link'
                        onClick={() =>
                            deleteFromSelect(element.feature?.properties?.Id)
                        }
                    />
                </li>
            ));
            if (list.length) {
                JSX.push(<ul className='layer-list'>{list}</ul>);
            }
        });
        // console.log(a);
        setListByFloorJSX(JSX);
    };

    return (
        <>
            {/* <UnorderedListOutlined
                id='group-select-btn'
                onClick={toggleClickMode}
                data-click-mode={clickMode}
            /> */}
            <div
                className={`group-select-wrapper ${
                    clickMode === 'select' ? 'show-select-wrapper' : ''
                }`}

            >
                <div
                    id='group-select-btn'
                    onClick={toggleClickMode}
                    data-click-mode={clickMode}
                    className='select-group-step'
                >
                    {clickMode === 'click' ? (
                        <UnorderedListOutlined />
                    ) : (
                        <DeleteOutlined />
                    )}
                </div>
                {/* <button onClick={() => deleteFromSelect(264)}>click me</button> */}
                <div className='group-select'>
                    {selectList.length ? (
                        <>
                            {listByFloorJSX}
                            <div className='list-count-wrapper'>
                                <Button
                                    id='select-list-count'
                                    onClick={onGroupEdit}
                                >
                                    <EditOutlined />
                                    <br /> [{selectList.length}]
                                </Button>
                            </div>
                        </>
                    ) : 'click on map to choose [parking-spot, corridor, led, camera]'}
                </div>
            </div>
        </>
    );
};

export default MapSelectList;
