import React from 'react';
import { Form, Slider } from 'antd';
import { PrinterOutlined } from '@ant-design/icons';

const CorridorRollupEdit = () => {
    return (
        <Form.Item
            name='height'
            label={<PrinterOutlined />}
            rules={[{ required: true }]}
        >
            <Slider value={50}  />
        </Form.Item>
    );
};

export default CorridorRollupEdit;
