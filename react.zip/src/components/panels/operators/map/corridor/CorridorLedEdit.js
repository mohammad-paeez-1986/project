import { useState } from 'react';
import { Form, Slider } from 'antd';
import { BulbOutlined } from '@ant-design/icons';

const CorridorLedEdit = () => {
    const [first, setFirst] = useState(0);
    return (
        <>
            <Form.Item
                name='brightness'
                label={<BulbOutlined />}
                rules={[{ required: true }]}
            >
                <Slider value={50}  />
            </Form.Item>
        </>
    );
};

export default CorridorLedEdit;
