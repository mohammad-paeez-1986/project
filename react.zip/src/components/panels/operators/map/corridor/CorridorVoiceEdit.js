import React, { useState, useEffect } from 'react';
import axios from 'axios';
import notify from 'helpers/notify';
import t from 'helpers/translation';
import { Form, Select } from 'antd';

const { Option } = Select;

const CorridorVoiceEdit = () => {
    const [voiceList, setVoiceList] = useState([]);
    const [selectLoading, setSelectLoading] = useState(true);

    useEffect(async () => {
        try {
            const { results } = await axios.get(
                'device/device_message/?message_type=2'
            );

            setVoiceList(results);
            setSelectLoading(false);
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    return (
        <Form.Item
            name='message_id'
            label={t('voice')}
            rules={[{ required: true }]}
        >
            <Select loading={selectLoading}>
                {voiceList.map((item) => (
                    <Option key={item.id} value={item.id}>
                        {item.value}
                    </Option>
                ))}
            </Select>
        </Form.Item>
    );
};

export default React.memo(CorridorVoiceEdit);
