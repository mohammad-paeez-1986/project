import React, { useState, useEffect } from 'react';
import { Row, Col, Spin, Form, Input, Select, Slider, Button } from 'antd';
import t from 'helpers/translation';
import CorridorLedEdit from 'components/panels/operators/map/corridor/CorridorLedEdit';
import CorridorRollupEdit from 'components/panels/operators/map/corridor/CorridorRollupEdit';
import CorridorVoiceEdit from 'components/panels/operators/map/corridor/CorridorVoiceEdit';
import axios from 'axios';
import notify from 'helpers/notify';

const { Option } = Select;

const CorridorEdit = ({ list, closeModal, emptySelectList }) => {
    const [corridorIdList, setCorridorIdList] = useState([]);
    const [loading, setLoading] = useState(false);
    const [formPart, setFormPart] = useState('');
    const [formType, setFormType] = useState('');

    useEffect(() => {
        const idList = list.map((item) => {
            const id = item?.feature?.properties?.Id;
            if (id) {
                return id;
            }
        });

        setCorridorIdList(idList);
    }, [list]);

    const onTypeChange = (value) => {
        console.log(value);
        switch (value) {
            case 'led':
                setFormPart(<CorridorLedEdit />);
                break;
            case 'roll-up':
                setFormPart(<CorridorRollupEdit />);
                break;
            case 'voice':
                setFormPart(<CorridorVoiceEdit />);
                break;
            default:
                break;
        }

        // set form type to recognize where send api
        setFormType(value);
    };

    const getApiAndListNameByFormType = () => {
        switch (formType) {
            case 'led':
                return {
                    api: 'device/light/bulk_light_for_corridor/',
                    listName: 'corridor_list',
                };
            case 'roll-up':
                return {
                    api: 'device/banner/bulk_roll_up_for_corridor/',
                    listName: 'corridor_list',
                };
            // case 'voice':
            //     return {
            //         api: 'camera/camera/bulk_play_voice/',
            //         listName: 'camera_list',
            //     };
            default:
                break;
        }
    };

    const onFinish = async (values) => {
        delete values.type;

        const { api, listName } = getApiAndListNameByFormType();

        values[listName] = corridorIdList;

        setLoading(true);

        try {
            const data = await axios.post(api, values);
            notify.success(data);
            emptySelectList();
            closeModal();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <Row align='center'>
            <Col span={15}>
                <Spin spinning={loading}>
                    <Form
                        labelCol={{ span: 6 }}
                        wrapperCol={{ span: 24 }}
                        onFinish={onFinish}
                        autoComplete='off'
                    >
                        <Form.Item
                            name='type'
                            label={t('type')}
                            rules={[{ required: true }]}
                        >
                            <Select onChange={onTypeChange}>
                                <Option value='led' key='led'>
                                    {t('led')}
                                </Option>
                                <Option value='roll-up' key='roll-up'>
                                    {t('roll-up')}
                                </Option>
                                {/* <Option value='voice' key='voice'>
                                    {t('voice')}
                                </Option> */}
                            </Select>
                        </Form.Item>
                        {formPart}
                        {formPart && (
                            <div className='modal-footer'>
                                <Form.Item>
                                    <Button
                                        type='primary'
                                        htmlType='submit'
                                        className='wide-button'
                                    >
                                        {t('edit')}
                                    </Button>
                                </Form.Item>
                            </div>
                        )}
                    </Form>
                </Spin>
            </Col>
        </Row>
    );
};

export default CorridorEdit;
