import React, { useState, useEffect } from 'react';
import { Row, Col, Spin, Form, Input, Button } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import { getNumeric } from 'helpers/generalHelpers';

const CorridorWeightEdit = ({ id, closeModal }) => {
    const [loading, setLoading] = useState(false);
    const [form] = Form.useForm();

    useEffect(async (values) => {
        // setLoading(true);

        try {
            const data = await axios.get(`road/corridor/${id}/`);

            form.setFieldsValue({
                corridor_weight: data.corridor_weight,
            });
        } catch (error) {
            notify.danger(error);
        }

        // setLoading(false);
    }, []);

    const onFinish = async (values) => {
        setLoading(true);

        try {
            await axios.patch(`road/corridor/${id}/`, values);
            notify.success();
            closeModal()
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <Row align='center'>
            <Col span={15}>
                <Spin spinning={loading}>
                    <Form
                        labelCol={{ span: 7 }}
                        wrapperCol={{ span: 24 }}
                        onFinish={onFinish}
                        autoComplete='off'
                        form={form}
                    >
                        <Form.Item
                            label={t('weight')}
                            name='corridor_weight'
                            rules={[
                                {
                                    required: true,
                                },
                            ]}
                            normalize={(value) => getNumeric(value)}
                        >
                            <Input
                                placeholder={t('numeric_value')}
                                className='input-ltr'
                                maxLength={5}
                            />
                        </Form.Item>
                        <div className='modal-footer'>
                            <Form.Item>
                                <Button
                                    type='primary'
                                    htmlType='submit'
                                    className='wide-button'
                                >
                                    {t('edit')}
                                </Button>
                            </Form.Item>
                        </div>
                    </Form>
                </Spin>
            </Col>
        </Row>
    );
};

export default React.memo(CorridorWeightEdit);
