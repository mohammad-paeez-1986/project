import React, { useState, useEffect } from 'react';
import { Slider, Space } from 'antd';
import { BulbOutlined, PrinterOutlined } from '@ant-design/icons';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';

const SliderPart = ({ name, data }) => {
    const [iconComponent, setIconComponent] = useState();
    const [sliderValue, setSliderValue] = useState();
    const [confirmedSliderValue, setConfirmedSliderValue] = useState(0);

    const onSliderValueChange = async (e, name) => {
        try {
            let url, postData;

            if (name === 'light') {
                url = `device/light/${data.id}/change_light/`;
                postData = {
                    brightness: e,
                };
            } else if (name === 'roll-up') {
                url = `device/banner/${data.id}/roll_up/`;
                postData = {
                    height: e,
                };
            } else {
                return false;
            }

            const res = await axios.post(url, postData);

            notify.success(res)

            setConfirmedSliderValue(e);
        } catch (error) {
            setSliderValue(confirmedSliderValue);
            notify.danger(error);
        }
    };

    const onChange = (e) => {
        setSliderValue(e);
    };

    useEffect(() => {
        switch (name) {
            case 'light':
                setIconComponent(<BulbOutlined className='icon-slider' />);
                setSliderValue(data.brightness || 0);
                break;
            case 'roll-up':
                setIconComponent(<PrinterOutlined className='icon-slider' />);
                setSliderValue(data.height || 0);
                break;
            default:
                break;
        }
    }, [name]);

    return (
        <Space>
            {iconComponent && iconComponent}
            <Slider
                value={sliderValue}
                style={{ width: 200 }}
                onAfterChange={(e, s) => onSliderValueChange(e, name)}
                onChange={onChange}
            />
        </Space>
    );
};

export default SliderPart;
