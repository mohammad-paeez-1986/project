import React, { useState, useEffect } from 'react';
import axios from 'axios';
import notify from 'helpers/notify';
import t from 'helpers/translation';
import { Form, Select } from 'antd';

const { Option } = Select;

const ParkingSpotConditionEdit = () => {
    const [conditionList, setConditionList] = useState([]);
    const [selectLoading, setSelectLoading] = useState(true);

    const getConditionAsArray = (object) => {
        // console.log(object);
        let conditionArray = [];

        for (const key in object) {
            // console.log(key);
            conditionArray.push({ name: key, value: object[key] });
        }

        return conditionArray;
    };

    useEffect(async () => {
        try {
            const res = await axios.get(
                'parking_spot/parking_spot/return_all_parking_condition/'
            );

            setConditionList(
                getConditionAsArray(res?.parking_spot_condition_type)
            );
            setSelectLoading(false);
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    return (
        <Form.Item
            name='parking_spot_condition'
            label={t('condition')}
            rules={[{ required: true }]}
        >
            <Select loading={selectLoading}>
                {conditionList.map((item) => (
                    <Option key={item.value} value={item.value}>
                        {t(item.name)}
                    </Option>
                ))}
            </Select>
        </Form.Item>
    );
};

export default React.memo(ParkingSpotConditionEdit);
