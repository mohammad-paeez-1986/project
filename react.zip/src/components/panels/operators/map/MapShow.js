import React, { useState, useEffect, useRef } from 'react';
import { MapContainer, LayersControl, GeoJSON } from 'react-leaflet';
// import { useMapEvents } from 'react-leaflet/hooks'
import { useMapEvents } from 'react-leaflet/hooks';

import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import config from 'config/geoserver.json';
import t from 'helpers/translation';
import { Select, Empty, Modal, Drawer, Button } from 'antd';
import ParkShow from 'components/panels/operators/map/ParkShow';
import MapMenu from 'components/panels/operators/map/MapMenu';
import CameraSendVoice from 'components/panels/operators/map/camera/CameraSendVoice';
import LedSendMessage from 'components/panels/operators/map/led/LedSendMessage';
import MapSelectList from 'components/panels/operators/map/MapSelectList';
import MapComponent from 'components/panels/operators/map/MapComponent';
import CorridorEdit from 'components/panels/operators/map/corridor/CorridorEdit';
import CorridorWeightEdit from 'components/panels/operators/map/corridor/CorridorWeightEdit';
import ParkingSpotEdit from 'components/panels/operators/map/parking-spot/ParkingSpotEdit';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import ReportShow from 'components/panels/operators/report/ReportShow';
import { MapProvider } from 'contexts/MapContext';


const { Option } = Select;

const MapShow = () => {
    const [selectedId, setSelectedId] = useState(null);
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [modalTitle, setModalTitle] = useState('');
    const [modalContent, setModalContent] = useState(null);
    const [modalWidth, setModalWidth] = useState(376);

    const [highlightList, setHighlightList] = useState([]);
    const [drawerVisible, setDrawerVisible] = useState(false);
    const [clickMode, setClickMode] = useState('click');
    const [count, setCount] = useState(0);
    const [selectList, setSelectList] = useState([]);
    const selectType = useRef('');

    const [occupiedSpotList, setOccupiedSpotList] = useState([]);
    const [vacantSpotList, setVacantSpotList] = useState([]);
    const [outSpotList, setOutSpotList] = useState([]);

    const groupSelectButtonElement =
        document.getElementById('group-select-btn');
    const selectListCountElement = document.getElementById('select-list-count');

    const toggleClickMode = () => {
        if (groupSelectButtonElement.dataset.clickMode === 'click') {
            setClickMode('select');
            groupSelectButtonElement.dataset.clickMode = 'select';
        } else {
            emptySelectList();
            setClickMode('click');
            groupSelectButtonElement.dataset.clickMode = 'click';
        }
    };

    const getSelectType = (layerId) => {
        switch (true) {
            case layerId.startsWith('park'):
                return 'park';
            case layerId.startsWith('path'):
                return 'path';
        }
    };

    const emptySelectList = () => {
        // selectList.current = [];
        setSelectList([]);
        if (selectListCountElement) {
            selectListCountElement.innerHTML = null;
        }
    };

    const onGroupEdit = () => {
        if (selectList.length) {
            setModalWidth(567);
            setIsModalVisible(true);

            switch (selectType.current) {
                case 'route':
                    setModalContent(
                        <CorridorEdit
                            list={selectList}
                            closeModal={closeModal}
                            emptySelectList={emptySelectList}
                        />
                    );
                    setModalTitle(t('edit_for_path'));
                    break;
                case 'park':
                    setModalContent(
                        <ParkingSpotEdit
                            list={selectList}
                            closeModal={closeModal}
                            emptySelectList={emptySelectList}
                            selectType={selectType}
                            setChangedSpotConditionMultiple={
                                setChangedSpotConditionMultiple
                            }
                        />
                    );
                    setModalTitle(t('edit_for_park'));
                    break;
                case 'camera':
                    setModalContent(
                        <CameraSendVoice
                            list={selectList}
                            closeModal={closeModal}
                            emptySelectList={emptySelectList}
                            selectType={selectType}
                        />
                    );
                    setModalTitle(t('edit_camera_voice'));
                    break;
                case 'LED':
                    setModalContent(
                        <LedSendMessage
                            list={selectList}
                            closeModal={closeModal}
                            emptySelectList={emptySelectList}
                            selectType={selectType}
                        />
                    );
                    setModalTitle(t('edit_LED_message'));
                    break;
                default:
                    break;
            }

            //     if (selectType.current === 'route') {
            //         setModalContent(
            //             <CorridorEdit
            //                 list={selectList}
            //                 closeModal={closeModal}
            //                 emptySelectList={emptySelectList}
            //             />
            //         );
            //         setModalTitle(t('edit_for_path'));
            //     } else if (selectType.current === 'park') {
            //         setModalContent(
            //             <ParkingSpotEdit
            //                 list={selectList}
            //                 closeModal={closeModal}
            //                 emptySelectList={emptySelectList}
            //                 selectType={selectType}
            //             />
            //         );
            //         setModalTitle(t('edit_for_park'));
            //     }
            // } else if (selectType.current === 'camera') {
            //     alert('camera')
            //     setModalContent(
            //         <CameraSendVoice
            //             list={selectList}
            //             closeModal={closeModal}
            //             emptySelectList={emptySelectList}
            //             selectType={selectType}
            //         />
            //     );
            //     setModalTitle(t('edit_for_park'));
            // }else {
            //     alert('none')
        }
    };

    const closeModal = () => {
        setIsModalVisible(false);
    };

    const onDrawerClose = () => {
        setDrawerVisible(false);
        setHighlightList([]);
    };

    const doHighLight = (list) => {
        setHighlightList(list);
    };

    const toggleDrawer = () => {
        setDrawerVisible(!drawerVisible);
        setHighlightList([]);
    };

    const emptyConditionList = () => {
        setVacantSpotList([]);
        setOccupiedSpotList([]);
        setOutSpotList([]);
    };

    const changeParkCondition = (fromCondition, to, id) => {
        // 1:vacant, 2:occupied, 3:out
        // console.log(fromCondition, '-', to, '-', 'id');
        let index;
        switch (fromCondition) {
            case 1:
                index = vacantSpotList.indexOf(id);
                if (index) {
                    vacantSpotList.splice(index, 1);
                }
                break;
            case 2:
                index = occupiedSpotList.indexOf(id);
                if (index) {
                    occupiedSpotList.splice(index, 1);
                }
                break;
            case 3:
                index = outSpotList.indexOf(id);
                if (index) {
                    outSpotList.splice(index, 1);
                }
                break;
            default:
                break;
        }

        switch (to) {
            case 1:
                vacantSpotList.push(id);
                setVacantSpotList(vacantSpotList);
                break;
            case 2:
                occupiedSpotList.push(id);
                setOccupiedSpotList(occupiedSpotList);
                break;
            case 3:
                outSpotList.push(id);
                setOutSpotList(outSpotList);
                break;
            default:
                break;
        }
    };

    const setChangedSpotConditionMultiple = (to, idList) => {
        let index;
        idList.forEach((item) => {
            index = vacantSpotList.indexOf(item);
            if (index) {
                vacantSpotList.splice(index, 1);
            }
            index = occupiedSpotList.indexOf(item);
            if (index) {
                occupiedSpotList.splice(index, 1);
            }
            index = outSpotList.indexOf(item);
            if (index) {
                outSpotList.splice(index, 1);
            }
        });

        switch (to) {
            case 1:
                setVacantSpotList(vacantSpotList.concat(idList));
                break;
            case 2:
                setOccupiedSpotList(occupiedSpotList.concat(idList));
                break;
            case 3:
                setOutSpotList(outSpotList.concat(idList));
                break;
            default:
                break;
        }
        console.log(outSpotList);
        console.log(idList);
        console.log(outSpotList.concat(idList));

        console.log(outSpotList);
    };

    const openParkShowModal = (id) => {
        setSelectedId(id);
        setModalWidth(1024);
        setIsModalVisible(true);
        setModalContent(
            <ParkShow id={id} changeParkCondition={changeParkCondition} />
        );
        setModalTitle(t('park_place', { number: id }));
    };

    const openCorridorWeighModal = (id) => {
        setModalWidth(560);
        setIsModalVisible(true);
        setModalContent(<CorridorWeightEdit id={id} closeModal={closeModal} />);
        setModalTitle(t('edit_corridor', { number: id }));
    };

   

   
    return (
        <MapProvider>
            
            <div className='map-container'>
                <MapMenu toggleDrawer={toggleDrawer}/>
                <MapComponent
                    doHighLight={doHighLight}
                    highlightList={highlightList}
                    selectType={selectType}
                    openParkShowModal={openParkShowModal}
                    emptyConditionList={emptyConditionList}
                    vacantSpotList={vacantSpotList}
                    setVacantSpotList={setVacantSpotList}
                    outSpotList={outSpotList}
                    setOutSpotList={setOutSpotList}
                    occupiedSpotList={occupiedSpotList}
                    setOccupiedSpotList={setOccupiedSpotList}
                    openCorridorWeighModal={openCorridorWeighModal}
                    selectList={selectList}
                    setSelectList={setSelectList}
                />

                <Modal
                    title={modalTitle}
                    visible={isModalVisible}
                    footer={null}
                    destroyOnClose={true}
                    width={modalWidth}
                    onCancel={closeModal}
                >
                    {modalContent}
                </Modal>

                <MapSelectList
                    selectListStateArray={[selectList, setSelectList]}
                    toggleClickMode={toggleClickMode}
                    onGroupEdit={onGroupEdit}
                    clickMode={clickMode}
                />
            </div>
            <Drawer
                className='chart-drawer'
                placement='bottom'
                maskStyle={{ display: 'none' }}
                onClose={onDrawerClose}
                visible={drawerVisible}
                closable={false}
                forceRender={true}
                afterVisibleChange={(e) => {
                    if (e) {
                        document.body.style.removeProperty('overflow-y');
                        document.body.style.removeProperty('width');
                    }
                }}
            >
                <ReportShow
                    doHighLight={doHighLight}
                    toggleDrawer={toggleDrawer}
                />
            </Drawer>
        </MapProvider>
    );
};

export default React.memo(MapShow);
