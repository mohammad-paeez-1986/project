import React, { useState, useEffect } from 'react';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import {
    Row,
    Col,
    Table,
    Descriptions,
    Input,
    Select,
    InputNumber,
    Divider,
    Radio,
} from 'antd';
import { formatDate, formatNumber } from 'helpers/generalHelpers';
import SliderPart from 'components/panels/operators/map/SliderPart';
import VoicePart from 'components/panels/operators/map/VoicePart';
import PlatePart from 'components/panels/operators/map/PlatePart';

const { TextArea } = Input;
const { Option } = Select;

const ParkShow = ({ id, changeParkCondition }) => {
    const [parkingSpotData, setParkingSpotData] = useState({});
    const [parkingSpotDataDetail, setParkingSpotDetail] = useState([]);
    const [loading, setLoading] = useState(true);
    const [parkCondition, setParkCondition] = useState('');

    useEffect(async () => {
        try {
            const data = await axios.get(`general/full_parking_spot/${id}/`);

            setParkingSpotData(data);
            setParkCondition(data?.parking_spot?.parking_condition);

            // set detail for show in table
            const {
                base_price,
                car_plate,
                description,
                discount,
                enter_time,
                locative_group,
                reservation,
            } = data;

            setParkingSpotDetail([
                {
                    base_price,
                    car_plate,
                    description,
                    discount,
                    enter_time,
                    locative_group,
                    reservation,
                },
            ]);
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    }, [id]);

    const onConditionChange = async (e) => {
        const newValue = e.target.value;

        try {
            await axios.post(
                'parking_spot/parking_spot/bulk_edit_multi_spot_condition/',
                {
                    parking_spot_list_id: [id],
                    parking_spot_condition: newValue,
                }
            );

            setParkCondition(newValue);
            changeParkCondition(parkCondition, newValue, id);
            notify.success();
        } catch (error) {
            notify.danger(error);
        }
    };

    return (
        <div className='parking-spot'>
            <Row justify='space-between' gutter={[32, 40]}>
                <Col xs={24} sm={12} lg={8}>
                    {parkingSpotData?.parking_spot?.light_detail && (
                        <>
                            <Row align='center'>
                                <SliderPart
                                    default={0}
                                    name='light'
                                    data={
                                        parkingSpotData?.parking_spot
                                            ?.light_detail
                                    }
                                />
                            </Row>
                            <br />
                            <br />
                        </>
                    )}

                    {parkingSpotData?.parking_spot?.banner_detail && (
                        <Row align='center'>
                            <SliderPart
                                default={0}
                                name='roll-up'
                                data={
                                    parkingSpotData?.parking_spot?.banner_detail
                                }
                            />
                        </Row>
                    )}
                </Col>
                <Col xs={24} sm={12} lg={8}>
                    <VoicePart />
                </Col>
                <Col xs={24} sm={12} lg={8}>
                    <PlatePart />
                </Col>
            </Row>
            <Divider dashed />
            <Row align='center'>
                <Radio.Group
                    className='park-condition'
                    value={parkCondition}
                    buttonStyle='solid'
                    size='small'
                    onChange={onConditionChange}
                >
                    <Radio.Button value={1}>{t('vacant')}</Radio.Button>
                    <Radio.Button value={2}>{t('occupied')}</Radio.Button>
                    <Radio.Button value={3}>{t('inactive')}</Radio.Button>
                </Radio.Group>
            </Row>
            <Divider dashed />
            <Row justify='center'>
                <Col span={24}>
                    <Descriptions
                        layout='vertical'
                        bordered
                        size='small'
                        column={{ lg: 6, md: 6, sm: 3, xs: 1 }}
                        labelStyle={{ fontSize: 12, color: '#345' }}
                    >
                        <Descriptions.Item label={t('enter_time')}>
                            {parkingSpotData.enter_time
                                ? formatDate(parkingSpotData.enter_time)
                                : '-'}
                        </Descriptions.Item>
                        <Descriptions.Item label={t('base_price')}>
                            {parkingSpotData.best_price
                                ? formatNumber(parkingSpotData.best_price)
                                : '-'}
                        </Descriptions.Item>
                        <Descriptions.Item label={t('locative_group')}>
                            {parkingSpotData.locative_group
                                ? formatNumber(parkingSpotData.locative_group)
                                : '-'}
                        </Descriptions.Item>
                        <Descriptions.Item label={t('reservation')}>
                            {parkingSpotData.reservation || '-'}
                        </Descriptions.Item>
                        <Descriptions.Item label={t('discount')}>
                            <Row align='center'>
                                <Col xs={20} sm={12}>
                                    <InputNumber
                                        defaultValue={
                                            parkingSpotData.discount || ''
                                        }
                                        min={0}
                                        max={100}
                                        onPressEnter={() => {
                                            alert('salam');
                                        }}
                                        disabled={
                                            parkingSpotData.discount
                                                ? true
                                                : false
                                        }
                                    />
                                </Col>
                            </Row>
                        </Descriptions.Item>
                        <Descriptions.Item label={t('description')}>
                            {/* <Row align='center'>
                                <Col xs={20} sm={16}>
                                    <TextArea
                                        onPressEnter={() => {
                                            alert('salamati');
                                        }}
                                    />
                                </Col>
                            </Row> */}
                            {parkingSpotData.description || '-'}
                        </Descriptions.Item>
                    </Descriptions>
                </Col>
            </Row>
        </div>
    );
};

export default ParkShow;
