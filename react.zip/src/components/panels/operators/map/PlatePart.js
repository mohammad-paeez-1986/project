import React from 'react';
import PlateComponent from 'components/common/PlateComponent';
import PlateComp from 'components/common/PlateComp';
import { Row, Col, Form, Select, Button } from 'antd';
import t from 'helpers/translation';

const PlatePart = () => {
    const onFinish = (values) => {
        console.log(values);
    };

    return (
        <Row align='center' style={{ marginTop: 0 }}>
            <Col >
                <Form
                    // labelCol={{ span: 7 }}
                    onFinish={onFinish}
                    autoComplete='off'
                >
                    <PlateComp scale={1}/>
                    <br />
                    <div className='modal-footer' style={{ marginTop: -24 }}>
                        <Form.Item>
                            <Button htmlType='submit'>{t('add')}</Button>
                        </Form.Item>
                    </div>
                </Form>
            </Col>
        </Row>
    );
};

export default PlatePart;
