import { useState, useEffect } from 'react';
import { Row, Col, Spin, Form, Input, Select, Switch, Button } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import {
    getNumericFormatted,
    getNumeric,
    getPercent,
    formatNumber,
    unformat,
} from 'helpers/generalHelpers';

import { numberToPlate, carListWithStringPlateNumber } from 'helpers/plate';

const { Option } = Select;
const { TextArea } = Input;

const ConsiderationAdd = ({ refreshData, closeModal }) => {
    const [loading, setLoading] = useState(false);
    const [carList, setCarList] = useState([]);
    const [carsSelectLoading, setCarsSelectLoading] = useState(true);

    useEffect(async () => {
        try {
            const { results } = await axios.get('car/car_plate/');

            // const carsWithStringPlateNumber = results.map((item) => {
            //     const plate_number_string = numberToPlate(item.plate_number);

            //     if (plate_number_string !== undefined) {
            //         return {
            //             ...item,
            //             plate_number_string: plate_number_string,
            //         };
            //     }
            // });

            setCarsSelectLoading(false);
            setCarList(
                // carsWithStringPlateNumber.filter((item) => item !== undefined)
                carListWithStringPlateNumber(results)
            );
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    const onFinish = async (values) => {
        values.operator = 3;


        setLoading(true);

        try {
            const data = await axios.post(
                'car/description_for_car_plate/',
                values
            );

            setLoading(false);
            closeModal();
            refreshData();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <Row align='center'>
            <Col span={16}>
                <Spin spinning={loading}>
                    <Form
                        labelCol={{ span: 7 }}
                        wrapperCol={{ span: 24 }}
                        onFinish={onFinish}
                        autoComplete='off'
                    >
                        <Form.Item
                            name='car'
                            label={t('plate_number')}
                            rules={[{ required: true }]}
                        >
                            <Select
                                loading={carsSelectLoading}
                                allowClear
                                filterOption={(e, o) => {
                                    return (
                                        o.children.toString().indexOf(e) >= 0
                                    );
                                }}
                            >
                                {carList.map((item) => {
                                    return (
                                        <Option value={item.id} key={item.id}>
                                            {item.plate_number_string}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>

                        <Form.Item label={t('description')} name='description'>
                            <TextArea />
                        </Form.Item>

                        <Form.Item name='invisible' label={t('invisible')}>
                            <Switch />
                        </Form.Item>

                        <div className='modal-footer'>
                            <Form.Item>
                                <Button
                                    type='primary'
                                    htmlType='submit'
                                    className='wide-button'
                                >
                                    {t('add')}
                                </Button>
                            </Form.Item>
                        </div>
                    </Form>
                </Spin>
            </Col>
        </Row>
    );
};

export default ConsiderationAdd;
