import { useState, useEffect } from 'react';
import { Row, Col, Spin, Form, Input, Select, Switch, Button } from 'antd';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import {
    getNumericFormatted,
    getNumeric,
    getPercent,
    formatNumber,
    unformat,
} from 'helpers/generalHelpers';

const { Option } = Select;
const { TextArea } = Input;

const ConsiderationEdit = ({ id, refreshData, closeModal, rowData }) => {
    const [loading, setLoading] = useState(false);
    const [carList, setCarList] = useState([]);
    const [carsSelectLoading, setCarsSelectLoading] = useState(true);
    const [form] = Form.useForm();

    useEffect(async () => {
        try {
            const { results } = await axios.get('car/car_plate/');

            setCarsSelectLoading(false);
            setCarList(results);

            const { car, description, invisible } = rowData;
            form.setFieldsValue({
                car,
                description,
                invisible,
            });
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    const onFinish = async (values) => {
        values.operator = 3;

        console.log(values);

        setLoading(true);

        try {
            const data = await axios.patch(
                `car/description_for_car_plate/${id}`,
                values
            );

            setLoading(false);
            closeModal();
            refreshData();
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <Row align='center'>
            <Col span={16}>
                <Spin spinning={loading}>
                    <Form
                        form={form}
                        labelCol={{ span: 7 }}
                        wrapperCol={{ span: 24 }}
                        onFinish={onFinish}
                        autoComplete='off'
                        // initialValues={{ invisible: true }}
                    >
                        <Form.Item
                            name='car'
                            label={t('plate_number')}
                            rules={[{ required: true }]}
                        >
                            <Select
                                loading={carsSelectLoading}
                                allowClear
                                filterOption={(e, o) => {
                                    return (
                                        o.children.toString().indexOf(e) >= 0
                                    );
                                }}
                            >
                                {carList.map((item) => {
                                    return (
                                        <Option value={item.id} key={item.id}>
                                            {item.plate_number}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>

                        <Form.Item label={t('description')} name='description'>
                            <TextArea />
                        </Form.Item>

                        <Form.Item
                            name='invisible'
                            label={t('invisible')}
                            valuePropName='checked'
                        >
                            <Switch />
                        </Form.Item>

                        <div className='modal-footer'>
                            <Form.Item>
                                <Button
                                    type='primary'
                                    htmlType='submit'
                                    className='wide-button'
                                >
                                    {t('add')}
                                </Button>
                            </Form.Item>
                        </div>
                    </Form>
                </Spin>
            </Col>
        </Row>
    );
};

export default ConsiderationEdit;
