import React, { useState, useEffect } from 'react';
import t from 'helpers/translation';
import { Table, Card, Space, Modal, Popconfirm } from 'antd';
import {
    FormOutlined,
    DeleteOutlined,
    BarChartOutlined,
} from '@ant-design/icons';
import axios from 'axios';
import notify from 'helpers/notify';
// import OperatorAdd from 'components/panels/operators/profiel/OperatorAdd';
// import OperatorEdit from 'components/panels/operators/profiel/OperatorEdit';
import ProfileChart from 'components/panels/operators/profile/ProfileChart';
import useData from 'hooks/useData';
import { formatDate } from 'helpers/generalHelpers';

const ProfileList = () => {
    const { data, loading, total, pageSize, onChange, getData, setData } =
        useData('reports/profiles/');

    const [isModalVisible, setIsModalVisible] = useState(false);
    const [modalComponent, setModalComponent] = useState(null);
    const [modalTitle, setModalTitle] = useState('');

    const columns = [
        {
            title: t('name'),
            dataIndex: 'name',
        },
        {
            title: t('type'),
            render: ({ lines }) => lines.type,
        },
        {
            title: t('header'),
            render: ({ lines }) => lines.headers,
        },
        {
            title: t('report_period'),
            dataIndex: 'type_of_chart_points_in_result',
            // render: ({ lines }) => lines.headers,
        },
        {
            title: t('start'),
            render: ({ lines }) =>
                lines.start ? formatDate(lines.start) : '-',
        },
        {
            title: t('end'),
            render: ({ lines }) => (lines.end ? formatDate(lines.end) : '-'),
        },
        {
            title: t('report'),
            render: ({ id }) => (
                <BarChartOutlined
                    className='icon-link icon-edit'
                    onClick={() => showModal('report', id)}
                />
            ),
        },
    ];

    const closeModal = () => {
        setIsModalVisible(false);
    };

    const showModal = (title, rowData = null) => {
        setModalTitle(title);
        setIsModalVisible(true);

        if (title === 'report') {
            setModalComponent(<ProfileChart id={rowData} />);
        }

        // else if (title === 'edit_operator') {
        //     setModalComponent(
        //         <OperatorEdit
        //             rowData={rowData}
        //             refreshData={getData}
        //             closeModal={closeModal}
        //         />
        //     );
        // }
        // return false;
    };

    const remove = async (id) => {
        try {
            await axios.delete(`users/${id}/`);

            // remove from data
            const updatedData = data.filter((item) => item.id !== id);
            setData(updatedData);
        } catch (error) {
            notify.danger(error);
        }
    };

    return (
        <div className='fill-page'>
            <Card title={t('profile')}>
                <Table
                    loading={loading}
                    dataSource={data}
                    columns={columns}
                    rowKey={(record) => record.id}
                    scroll={{ x: true }}
                    pagination={{
                        total,
                        pageSize,
                        hideOnSinglePage: true,
                        onChange,
                    }}
                />
            </Card>
            <Modal
                title={t(modalTitle)}
                visible={isModalVisible}
                style={{ top: 10 }}
                footer={null}
                destroyOnClose={true}
                width={1024}
                onCancel={closeModal}
            >
                {modalComponent}
            </Modal>
        </div>
    );
};

export default ProfileList;
