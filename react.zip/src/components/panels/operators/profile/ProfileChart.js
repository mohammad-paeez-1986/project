import { useState, useEffect } from 'react';
import { Chart as ChartJs } from 'chart.js/auto';
import { Bar } from 'react-chartjs-2';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';
import { formatDate } from 'helpers/generalHelpers';

const ProfileChart = ({ id }) => {
    const [loading, setLoading] = useState(true);
    const [labelList, setLabelList] = useState([]);
    const [valueList, setValueList] = useState([]);

    useEffect(async () => {
        setLoading(true);

        try {
            const data = await axios.get(`reports/report/?profile_id=${id}/`);
            const chartData = data[0]?.chart_points;
            setLabelList(chartData.map((item) => item.date_time.substr(0, 10)));
            setValueList(chartData.map((item) => item.value));

            // setLabels(chart_points.map(item) => item.data_time)
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    }, []);

    return (
        // <p>salam</p>
        <Bar
            data={{
                labels: labelList,
                options: {
                    responsive: true,
                },
                datasets: [
                    {
                        id: 1,
                        label: '',
                        data: valueList,
                        backgroundColor: '#486',
                    },
                ],
            }}
        />
    );
};

export default ProfileChart;
