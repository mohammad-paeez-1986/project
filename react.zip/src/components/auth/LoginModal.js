import { useState } from 'react';
import { Col, Spin, Form, Input, Row, Card, Button } from 'antd';
import { useCookies } from 'react-cookie';
import { useNavigate } from 'react-router-dom';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';

const LoginModal = ({ userData }) => {
    const [loading, setLoading] = useState(false);
    const [cookies, setCookie] = useCookies(['token']);
    const navigate = useNavigate();

    const onFinish = async (values) => {
        setLoading(true);

        values.username = userData.username;

        const { username, password } = values;

        try {
            const { token, role } = await axios.post('login/', {
                username,
                password,
            });

            setCookie('token', token, { path: '/' });
            setCookie('type', role, { path: '/' });

            axios.defaults.headers.common['Authorization'] = 'Token ' + token;

            navigate('/', { replace: true });
        } catch (error) {
            notify.danger(error);
        }

        setLoading(false);
    };

    return (
        <Row align='center' className='login-modal'>
            <Spin spinning={loading}>
                <div className='text-center'>
                    {userData.role === 'admin' ? (
                        <img src='/assets/images/admin.svg' />
                    ) : (
                        <img src='/assets/images/operator.svg' />
                    )}
                    <p className='username'>{userData.username}</p>
                    <br />
                </div>
                <Form
                    labelCol={{ span: 7 }}
                    wrapperCol={{ span: 24 }}
                    onFinish={onFinish}
                    autoComplete='off'
                >
                    <Form.Item
                        // label={t('password')}
                        name='password'
                        rules={[
                            {
                                required: true,
                                message: t('password_required'),
                            },
                        ]}
                    >
                        <Input.Password
                            // ref={inputRef}
                            autoFocus
                            size='large'
                            placeholder={t('password')}
                        />
                    </Form.Item>
                    <div className='modal-footer'>
                        <Form.Item>
                            <Button
                                type='primary'
                                htmlType='submit'
                                className='wide-button'
                            >
                                {t('login')}
                            </Button>
                        </Form.Item>
                    </div>
                </Form>
            </Spin>
        </Row>
    );
};

export default LoginModal;
