import { useEffect, useState } from 'react';
import { useCookies } from 'react-cookie';
import { useNavigate } from 'react-router-dom';
import { Layout, Col, Row, Card, Button, Modal } from 'antd';
import LoginModal from 'components/auth/LoginModal';
import t from 'helpers/translation';
import axios from 'axios';
import notify from 'helpers/notify';

const { Header, Footer, Content } = Layout;

const Login = () => {
    const [cookies, setCookie] = useCookies(['token']);
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [selectedUserData, setSelectedUserData] = useState(null);
    const navigate = useNavigate();

    useEffect(async () => {
        if (cookies['token']) {
            navigate('/', { replace: true });
        }

        try {
            const data = await axios.get('users');
            setLoading(false);
            setUsers(data.results);
        } catch (error) {
            notify.danger(error);
        }
    }, []);

    // if token exists go to Base component

    const doLogin = async () => {
        try {
            const { token, role } = await axios.post('login/', {
                username: 'admin',
                password: '12345',
            });

            setCookie('token', token);
            setCookie('type', role);

            axios.defaults.headers.common['Authorization'] = 'Token ' + token;

            navigate('/', { replace: true });
        } catch (error) {
            notify.danger(error);
        }
    };

    const onSelectUsername = (userData) => {
        setSelectedUserData(userData);
        setIsModalVisible(true);
    };

    const closeModal = () => {
        setIsModalVisible(false);
    };

    return (
        <Layout>
            <Header className='header'>
                <p className='header-title-login'> LOGIN</p>
            </Header>
            <Content className='content'>
                <div>
                    <Row className='login-container'>
                        <Row className='users-container'>
                            {users.map(({ username, role }) => {
                                return (
                                    <Col xs={24} sm={9} md={10} lg={10} xl={10}>
                                        <Card
                                            loading={loading}
                                            className='user-card'
                                            onClick={() =>
                                                onSelectUsername({
                                                    username,
                                                    role,
                                                })
                                            }
                                        >
                                            {role === 'admin' ? (
                                                <img src='/assets/images/admin.svg' />
                                            ) : (
                                                <img src='/assets/images/operator.svg' />
                                            )}
                                            <p className='username'>
                                                {username}
                                            </p>
                                        </Card>
                                    </Col>
                                );
                            })}

                            {/* <Button onClick={doLogin}>Login</Button> */}
                        </Row>
                    </Row>
                </div>
                <Modal
                    title={
                        selectedUserData?.role === 'admin'
                            ? t('admin_login')
                            : t('operator_login')
                    }
                    visible={isModalVisible}
                    footer={null}
                    destroyOnClose={true}
                    width={550}
                    onCancel={closeModal}
                >
                    <LoginModal userData={selectedUserData} />
                </Modal>
            </Content>
            {/* <Footer>Footer</Footer> */}
        </Layout>
    );
};

export default Login;
