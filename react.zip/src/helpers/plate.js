const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const cityNumbers = [];
for (let i = 10; i < 100; i++) {
    cityNumbers.push(i);
}

const alphabet = [
    // { title: '@@', value: '@@' },
    { title: 'الف', value: '01' },
    { title: 'ب', value: '02' },
    { title: 'پ', value: '03' },
    { title: 'ت', value: '04' },
    { title: 'ث', value: '05' },
    { title: 'ج', value: '06' },
    { title: 'چ', value: '07' },
    { title: 'ح', value: '08' },
    { title: 'خ', value: '09' },
    { title: 'د', value: '10' },
    { title: 'ذ', value: '11' },
    { title: 'ر', value: '12' },
    { title: 'ز', value: '13' },
    { title: 'ژ', value: '14' },
    { title: 'س', value: '15' },
    { title: 'ش', value: '16' },
    { title: 'ص', value: '17' },
    { title: 'ض', value: '18' },
    { title: 'ط', value: '19' },
    { title: 'ظ', value: '20' },
    { title: 'ع', value: '21' },
    { title: 'غ', value: '22' },
    { title: 'ف', value: '23' },
    { title: 'ق', value: '24' },
    { title: 'ک', value: '25' },
    { title: 'گ', value: '26' },
    { title: 'ل', value: '27' },
    { title: 'م', value: '28' },
    { title: 'ن', value: '29' },
    { title: 'و', value: '30' },
    { title: 'ه', value: '31' },
    { title: 'ی', value: '32' },
];

function numberToPlate(plateNum) {
    const plate = plateNum.toString();

    try {
        const alphabetObj = alphabet.find(
            (item) => item.value === plate.substr(2, 2)
        );

        const alphabetTitle = alphabetObj.title || '';
        const platesArray = [
            plate.substr(7, 2),
            ' ایران ',
            plate.substr(4, 3),
            alphabetTitle,
            plate.substr(0, 2),
        ];
        return platesArray;

        const plates = (
            <p className='plate'>
                {platesArray.map((item) => (
                    <span>{item}</span>
                ))}
            </p>
        );
        return plates;
    } catch (error) {
        console.warn(`plate number ${plateNum} is wrong`);
    }
}

function carListWithStringPlateNumber(results) {
    const carsWithStringPlateNumber = results.map((item) => {
        const plate_number_string = numberToPlate(item.plate_number);

        if (plate_number_string !== undefined) {
            return {
                ...item,
                plate_number_string: plate_number_string,
            };
        }
    });

    return carsWithStringPlateNumber.filter((item) => item !== undefined);
}

export {
    numbers,
    cityNumbers,
    alphabet,
    numberToPlate,
    carListWithStringPlateNumber,
};
