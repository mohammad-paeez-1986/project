import { Store } from 'react-notifications-component';
import t from 'helpers/translation';

class Notify {
    create(message) {
        Store.addNotification({
            message: message,
            type: this.type,
            insert: 'bottom',
            container: 'bottom-right',
            animationIn: ['animate__animated animate__flipInX'],
            animationOut: ['animate__animated animate__fadeOut'],
            dismiss: {
                duration: 3000,
                // onScreen: true,
                pauseOnHover: true,
                // showIcon: true,
            },
            slidingExit: {
                duration: 500,
            },
        });
    }

    danger(message) {
        this.message = message;
        this.type = 'danger';
        this.create(message);
    }

    success(message = t('successfuly_done')) {
        this.type = 'success';
        this.create(message);
    }
}

const notify = new Notify();

export default notify;
