export const formatNumber = (number) => {
    if (number) {
        return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }
};

export const toEnglishDigits = (val) => {
    const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

    if (val) {
        const english = val
            .toString()
            .replace(/[۰-۹]/g, (char) => persian.indexOf(char));
        return english;
    }
};

export const getNumeric = (val) => {
    if (val) {
        return toEnglishDigits(val).replace(/\D/g, '');
    }
};

export const getNumericFormatted = (val) => {
    if (val) {
        return formatNumber(toEnglishDigits(val).replace(/\D/g, ''));
    }
};

export const unformat = (val) => {
    if (val) {
        return parseInt(val.replace(/\,/g, ''));
    }
};

export const getPercent = (val) => {
    if (val) {
        const number = getNumeric(val);
        if (number > 100 || number < 0) {
            return null;
        }

        return number;
    }
};

export const formatDate = (date) => {
    const dateTime = new Date(date);
    const dateTimeArray = toEnglishDigits(dateTime.toLocaleString()).split(',');
    return (
        <p className='date-time-format'>
            {dateTimeArray[0]}
            <span className='time-format'>{dateTimeArray[1]}</span>
        </p>
    );
};

export const dateTimeToString = (date) => {
    const dateArray = date.split('T');
    return `${dateArray[0]} ${dateArray[1].substr(0, 5)}`;
};

export const makeQs = (array = null) => {
    // remove empty element
    let array1 = array.filter((item) => item);

    if (array1.length) {
        return '?' + array1.join('&');
    }

    return '';
};

export const createFilterArray = (values) => {
    let filterArray = [];
    for (const key in values) {
        if (values[key]) {
            filterArray.push(`${key}=${values[key]}`);
        }
    }

    return filterArray;
};
