const path = window.location.pathname;
const pathArray = path.split('/');
let menuKey, subMenuKey;

if (pathArray.length === 2) {
    menuKey = pathArray[1];
} else {
    menuKey = pathArray[2];
    subMenuKey = pathArray[1];
}

export { menuKey, subMenuKey };
