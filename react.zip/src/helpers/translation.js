import i18n from 'i18next';

export default i18n.t

