import ReactDOM from 'react-dom';
import './App.css';
import App from './App';
import i18n from 'i18next';
import HttpApi from 'i18next-http-backend';
import { initReactI18next } from 'react-i18next';
import { Cookies } from 'react-cookie';
import { ConfigProvider } from 'antd';
import faIR from 'antd/es/locale/fa_IR';
import enUS from 'antd/es/locale/en_US';
import axios from 'axios';
import { ReactNotifications } from 'react-notifications-component';
import 'animate.css';

// create instance of Cookies and put into context
const cookies = new Cookies();

// set axios defaults
axios.defaults.baseURL = process.env.REACT_APP_API_URL;
if (cookies.get('token')) {
    axios.defaults.headers.common['Authorization'] =
        'Token ' + cookies.get('token');
}

// set axios response interceptors
axios.interceptors.response.use(
    (result) => result.data.data,
    (error) => {
        if (error.response) {
            const errObj = error.response.data;
            // return Promise.reject(errObj[Object.keys(errObj)[0]]);
            let errorMsg = '';
            if (errObj?.message) {
                errorMsg += errObj?.message
            }

            if (errObj?.data) {
                errorMsg += errObj?.data
            }
            return Promise.reject(errorMsg);
        }

        const { status } = error.response;

        if (status === 401) {
            return Promise.reject('');
        }

        if (status === 404) {
            return Promise.reject(error.response.data.message);
        }

        return Promise.reject('');
    }
);

i18n.use(initReactI18next)
    .use(HttpApi)
    .init({
        fallbackLng: ['en'],
        // lng: cookies.get('lang'),
        lng: 'en',
        backend: {
            loadPath: '/assets/locales/{{lng}}/translation.json',
        },
        interpolation: {
            escapeValue: false,
        },
        react: { useSuspense: false },
    })
    .finally(() => {
        ReactDOM.render(
            // <ConfigProvider
            //     direction={i18n.language === 'fa' ? 'rtl' : 'ltr'}
            //     locale={i18n.language === 'fa' ? faIR : enUS}
            // >
            <>
                <ReactNotifications />
                <App />
            </>,
            // </ConfigProvider>,
            document.getElementById('root')
        );
    });
