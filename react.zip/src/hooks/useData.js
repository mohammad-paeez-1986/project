import { useState, useEffect } from 'react';
import axios from 'axios';
import notify from 'helpers/notify';
import { makeQs } from 'helpers/generalHelpers';

const useData = (url) => {
    const [loading, setLoading] = useState(true);
    const [data, setData] = useState([]);
    const [total, setTotal] = useState(0);
    const [pageSize, setPageSize] = useState(10);
    const [qs, setQs] = useState('');
    const [filterArray, setfilterArray] = useState([]);
    const [pagingArray, setPagingArray] = useState([]);

    useEffect(() => {
        getData();
    }, [qs]);

    const getData = async () => {
        setLoading(true);
        try {
            const data = await axios.get(url + qs);
            setLoading(false);
            setData(data.results);

            if (data.total !== total) {
                setTotal(data.count);
            }
        } catch (error) {
            notify.danger(error);
        }
    };

    const onChange = (page, perPage) => {
        const qsData = [];
        if (page !== 1) {
            qsData.push(`offset=${(page - 1) * perPage}`);
        }
        if (perPage !== pageSize) {
            setPageSize(perPage);
        }

        if (perPage !== 10) {
            qsData.push(`limit=${perPage}`);
        }

        setPagingArray(qsData);
        setQs(makeQs([...qsData, ...filterArray]));
    };
    
    const createFilterQs = (filterQsData) => {
        setfilterArray(filterQsData)
        // console.log([...pagingArray, ...filterQsData])
        setQs(makeQs([...pagingArray, ...filterQsData]));
    };

    return {
        data,
        loading,
        total,
        pageSize,
        onChange,
        getData,
        setData,
        createFilterQs,
        filterArray
    };
};

export default useData;
