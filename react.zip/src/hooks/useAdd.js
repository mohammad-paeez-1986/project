import { Button } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import t from 'helpers/translation';

const useAdd = (fn) => {
    return (
        <Button onClick={fn}>
            {/* {t('add')} */}
            <PlusOutlined />
        </Button>
    );
};

export default useAdd;
