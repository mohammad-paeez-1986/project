import React, { useState, useEffect } from 'react';
import { Button, Popover } from 'antd';
import { ControlOutlined } from '@ant-design/icons';
import t from 'helpers/translation';

const useFilter = (content, filterArray) => {
    // useEffect(() => {
    //     console.log(filterArray);
    // }, []);

    return (
        <Popover content={content} trigger='click'>
            <Button
                style={{ margin: " 0 10px" }}
                shape='round'
                type='dashed'
                className={filterArray.length && 'filter-exists'}
            >
                <ControlOutlined className='icon-filter' />
            </Button>
        </Popover>
    );

    
};

export default useFilter;
